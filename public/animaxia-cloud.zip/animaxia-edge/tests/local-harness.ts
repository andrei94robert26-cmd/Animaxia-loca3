/**
 * tests/local-harness.ts — in-memory bindings + wiring for the Animaxia edge
 * workers, so the REAL worker code (gateway + all six sub-workers) runs under
 * `bun tests/smoke-edge.mjs` and `bun tests/e2e-edge.mjs` without Cloudflare
 * credentials: no wrangler, no network to the KV/R2/DO/Queue backends.
 *
 * What it provides:
 *   • MemKV / MemR2 / MemCache / QueueStub / MemRateLimiter — structurally
 *     compatible with the KvLike / R2Like / CacheApiLike / QueueLike /
 *     DoNamespaceLike contracts in shared/types.ts.
 *   • HarnessCtx — EdgeCtx with collectible waitUntil promises.
 *   • makeEnv() — a full EdgeEnv where every SVC_* service binding routes to
 *     the real sub-worker module in-process. KV/R2 stores are shared BY NAME
 *     (EDGE_CACHE in the gateway is the same instance the cron worker sees),
 *     mirroring how the namespaces are shared on Cloudflare.
 *   • installFetchStub() — routes selected hosts (the cloud origin, HLS
 *     origins) to test handlers; everything else returns a hermetic 502.
 *   • installCaches() — exposes a MemCache as globalThis.caches.default so
 *     shared/cache.ts's L1 tier (edgeCacheApi()) works under bun.
 *
 * Known limitation: module-level singletons inside the workers (e.g. the
 * search catalog memory snapshot) live for the whole process — keep one
 * dataset per run or rely on the KV/TTL refresh paths.
 */

import type {
  EdgeEnv,
  EdgeCtx,
  EdgeWorker,
  KvLike,
  KvPutOptions,
  KvEntryWithMetadata,
  KvListKey,
  R2Like,
  R2ObjectLike,
  DoNamespaceLike,
  QueueLike,
  QueueBatch,
  ServiceBindingLike,
} from '../shared/types';
import type { CacheApiLike } from '../shared/cache';
import { resetConfigCache } from '../shared/config';
import { resetSecretCache } from '../shared/jwt';
import { resetMemoryRateLimits } from '../shared/rate-limit';
import { resetEdgeMetrics } from '../shared/metrics'; // FAZA 9 ops

import gatewayWorker from '../worker/src/index';
import searchWorker from '../search/src/index';
import aiWorker from '../ai/src/index';
import authWorker from '../auth/src/index';
import playerWorker from '../player/src/index';
import analyticsWorker from '../analytics/src/index';
import cronWorker from '../cron/src/index';

/* ------------------------------------------------------------------ KV ------ */

interface KvEntry {
  data: Uint8Array;
  expiresAtMs: number | null;
  metadata: unknown;
}

export class MemKV implements KvLike {
  private entries = new Map<string, KvEntry>();

  clear(): void {
    this.entries.clear();
  }

  private live(key: string): KvEntry | null {
    const entry = this.entries.get(key);
    if (!entry) return null;
    if (entry.expiresAtMs !== null && entry.expiresAtMs <= Date.now()) {
      this.entries.delete(key);
      return null;
    }
    return entry;
  }

  private text(entry: KvEntry): string {
    return new TextDecoder().decode(entry.data);
  }

  get(key: string): Promise<string | null>;
  get(key: string, type: 'json'): Promise<unknown>;
  get(key: string, type: 'text'): Promise<string | null>;
  get(key: string, type: 'arrayBuffer'): Promise<ArrayBuffer | null>;
  async get(key: string, type?: 'json' | 'text' | 'arrayBuffer'): Promise<unknown> {
    const entry = this.live(key);
    if (!entry) return null;
    if (type === 'arrayBuffer') return entry.data.slice().buffer as ArrayBuffer;
    const text = this.text(entry);
    if (type === 'json') {
      try {
        return JSON.parse(text) as unknown;
      } catch {
        return null;
      }
    }
    return text;
  }

  getWithMetadata(key: string, type: 'json'): Promise<KvEntryWithMetadata<unknown>>;
  getWithMetadata(key: string, type: 'text'): Promise<KvEntryWithMetadata<string | null>>;
  async getWithMetadata(key: string, type?: 'json' | 'text'): Promise<KvEntryWithMetadata<unknown>> {
    const entry = this.live(key);
    if (!entry) return { value: null, metadata: null };
    if (type === 'json') {
      try {
        return { value: JSON.parse(this.text(entry)) as unknown, metadata: entry.metadata };
      } catch {
        return { value: null, metadata: null };
      }
    }
    return { value: this.text(entry), metadata: entry.metadata };
  }

  async put(key: string, value: string | ReadableStream | ArrayBuffer, options?: KvPutOptions): Promise<void> {
    let data: Uint8Array;
    if (typeof value === 'string') data = new TextEncoder().encode(value);
    else if (value instanceof ArrayBuffer) data = new Uint8Array(value.slice(0));
    else data = new Uint8Array(await new Response(value).arrayBuffer());
    this.entries.set(key, {
      data,
      expiresAtMs: options?.expirationTtl ? Date.now() + Math.max(1, options.expirationTtl) * 1000 : null,
      metadata: options?.metadata ?? null,
    });
  }

  async delete(key: string): Promise<void> {
    this.entries.delete(key);
  }

  async list(options?: { prefix?: string; limit?: number }): Promise<{ keys: KvListKey[]; list_complete: boolean }> {
    const prefix = options?.prefix ?? '';
    const limit = options?.limit ?? 1000;
    const names = [...this.entries.keys()].filter((k) => k.startsWith(prefix)).sort();
    const slice = names.slice(0, limit);
    return { keys: slice.map((name) => ({ name })), list_complete: names.length <= slice.length };
  }

  /* ----------------------------------------------------- test helpers ----- */

  async setJson(key: string, value: unknown, ttlSec?: number): Promise<void> {
    await this.put(key, JSON.stringify(value), ttlSec ? { expirationTtl: ttlSec } : undefined);
  }

  dumpKeys(prefix = ''): string[] {
    return [...this.entries.keys()].filter((k) => k.startsWith(prefix));
  }

  size(): number {
    return this.entries.size;
  }
}

/* ------------------------------------------------------------------ R2 ------ */

interface R2Stored {
  data: Uint8Array;
  httpMetadata?: Record<string, string>;
  customMetadata?: Record<string, string>;
  etag: string;
}

const R2_HEADER_MAP: Record<string, string> = {
  contentType: 'content-type',
  contentLanguage: 'content-language',
  contentDisposition: 'content-disposition',
  contentEncoding: 'content-encoding',
  cacheControl: 'cache-control',
};

export class MemR2 implements R2Like {
  private objects = new Map<string, R2Stored>();

  clear(): void {
    this.objects.clear();
  }

  private obj(key: string, data: Uint8Array, stored: R2Stored, range?: { offset: number; length?: number }): R2ObjectLike {
    const end = range ? range.offset + (range.length ?? data.length - range.offset) : data.length;
    const slice = range ? data.slice(range.offset, end) : data;
    return {
      key,
      size: slice.byteLength,
      httpEtag: stored.etag,
      uploaded: new Date(),
      body: new Response(slice).body,
      writeHttpMetadata: (headers: Headers): void => {
        for (const [k, v] of Object.entries(stored.httpMetadata ?? {})) {
          headers.set(R2_HEADER_MAP[k] ?? k, v);
        }
      },
    };
  }

  async get(key: string, options?: { range?: { offset: number; length?: number } }): Promise<R2ObjectLike | null> {
    const stored = this.objects.get(key);
    if (!stored) return null;
    return this.obj(key, stored.data, stored, options?.range);
  }

  async head(key: string): Promise<R2ObjectLike | null> {
    const stored = this.objects.get(key);
    if (!stored) return null;
    return this.obj(key, stored.data, stored);
  }

  async put(
    key: string,
    value: ReadableStream | ArrayBuffer | Uint8Array | string,
    options?: { httpMetadata?: Record<string, string>; customMetadata?: Record<string, string> },
  ): Promise<R2ObjectLike | null> {
    let data: Uint8Array;
    if (typeof value === 'string') data = new TextEncoder().encode(value);
    else if (value instanceof ArrayBuffer) data = new Uint8Array(value.slice(0));
    else if (value instanceof Uint8Array) data = value.slice();
    else data = new Uint8Array(await new Response(value).arrayBuffer());
    const stored: R2Stored = {
      data,
      httpMetadata: options?.httpMetadata,
      customMetadata: options?.customMetadata,
      etag: `"${key.length.toString(16)}-${data.byteLength.toString(16)}"`,
    };
    this.objects.set(key, stored);
    return this.obj(key, data, stored);
  }

  async delete(key: string | string[]): Promise<void> {
    for (const k of Array.isArray(key) ? key : [key]) this.objects.delete(k);
  }

  /* test helper */
  async putBytes(key: string, data: Uint8Array, httpMetadata?: Record<string, string>): Promise<void> {
    await this.put(key, data, { httpMetadata });
  }
}

/* ----------------------------------------------------------- Cache API ------ */

export class MemCache implements CacheApiLike {
  private responses = new Map<string, Response>();

  clear(): void {
    this.responses.clear();
  }

  private urlOf(request: Request | string): string {
    return typeof request === 'string' ? request : request.url;
  }

  async match(request: Request | string): Promise<Response | null> {
    const hit = this.responses.get(this.urlOf(request));
    return hit ? hit.clone() : null;
  }

  async put(request: Request | string, response: Response): Promise<void> {
    this.responses.set(this.urlOf(request), response.clone());
  }

  async delete(request: Request | string): Promise<boolean> {
    return this.responses.delete(this.urlOf(request));
  }
}

/* ----------------------------------------------------------------- ctx ------ */

export class HarnessCtx implements EdgeCtx {
  readonly pending: Array<Promise<unknown>> = [];

  waitUntil(promise: Promise<unknown>): void {
    this.pending.push(Promise.resolve(promise).catch(() => undefined));
  }

  async flush(): Promise<void> {
    const all = [...this.pending];
    this.pending.length = 0;
    await Promise.all(all);
  }
}

/* --------------------------------------------------------------- queue ------ */

export class QueueStub implements QueueLike {
  readonly messages: unknown[] = [];

  clear(): void {
    this.messages.length = 0;
  }

  async send(message: unknown): Promise<void> {
    this.messages.push(message);
  }

  async sendBatch(messages: Array<{ body: unknown }>): Promise<void> {
    for (const m of messages) this.messages.push(m.body);
  }
}

/* -------------------------------------------------- Durable Object stub ----- */

/** Fixed-window in-memory twin of worker/src/ratelimiter-do.ts semantics. */
export class MemRateLimiter implements DoNamespaceLike {
  private windows = new Map<string, { count: number; resetAt: number }>();

  reset(): void {
    this.windows.clear();
  }

  idFromName(name: string): { name: string; toString(): string } {
    return { name, toString: () => name };
  }

  get(_id: { name: string; toString(): string }): { fetch(request: Request): Promise<Response> } {
    const self = this;
    return {
      async fetch(request: Request): Promise<Response> {
        const url = new URL(request.url);
        const jsonHeaders = { 'content-type': 'application/json; charset=utf-8' };
        if (url.pathname === '/reset') {
          self.windows.clear();
          return new Response('{"ok":true}', { headers: jsonHeaders });
        }
        if (url.pathname !== '/check') {
          return new Response('{"error":"not_found"}', { status: 404, headers: jsonHeaders });
        }
        const key = url.searchParams.get('key') || '';
        const limit = Number(url.searchParams.get('limit'));
        const windowSec = Math.max(1, Number(url.searchParams.get('windowSec')) || 60);
        if (!key || !Number.isFinite(limit) || limit <= 0) {
          return new Response('{"error":"bad_request"}', { status: 400, headers: jsonHeaders });
        }
        const now = Date.now();
        let win = self.windows.get(`rl:${key}`);
        if (!win || win.resetAt <= now) win = { count: 0, resetAt: now + windowSec * 1000 };
        win.count += 1;
        self.windows.set(`rl:${key}`, win);
        return new Response(
          JSON.stringify({
            allowed: win.count <= limit,
            limit,
            remaining: Math.max(0, limit - win.count),
            resetSec: Math.floor(win.resetAt / 1000),
          }),
          { headers: jsonHeaders },
        );
      },
    };
  }
}

/* ------------------------------------------------------ harness singletons -- */

const kvStores = new Map<string, MemKV>();
const r2Stores = new Map<string, MemR2>();
const memCache = new MemCache();
const queueStub = new QueueStub();
const rateLimiterStub = new MemRateLimiter();
const serviceCtxPool: HarnessCtx[] = [];

export function kvStore(name: string): MemKV {
  let kv = kvStores.get(name);
  if (!kv) {
    kv = new MemKV();
    kvStores.set(name, kv);
  }
  return kv;
}

export function r2Store(name: string): MemR2 {
  let r2 = r2Stores.get(name);
  if (!r2) {
    r2 = new MemR2();
    r2Stores.set(name, r2);
  }
  return r2;
}

export function cachesStub(): MemCache {
  return memCache;
}

export function queue(): QueueStub {
  return queueStub;
}

export function rateLimiter(): MemRateLimiter {
  return rateLimiterStub;
}

/** Flush every waitUntil promise registered by service-binding sub-calls. */
export async function flushServiceWaitUntils(): Promise<void> {
  const pool = [...serviceCtxPool];
  serviceCtxPool.length = 0;
  for (const ctx of pool) await ctx.flush();
}

/* ------------------------------------------------------------ env factory --- */

export interface MakeEnvOptions {
  env?: Partial<EdgeEnv>;
  /** Binding names to omit (e.g. 'ANALYTICS_QUEUE' to force the buffer path). */
  without?: string[];
}

export function makeEnv(opts: MakeEnvOptions = {}): EdgeEnv {
  const env: EdgeEnv = {
    EDGE_CONFIG: kvStore('EDGE_CONFIG'),
    EDGE_CACHE: kvStore('EDGE_CACHE'),
    EDGE_RATELIMIT: kvStore('EDGE_RATELIMIT'),
    EDGE_REPLAY: kvStore('EDGE_REPLAY'),
    SEARCH_CACHE: kvStore('SEARCH_CACHE'),
    EMBEDDINGS_CACHE: kvStore('EMBEDDINGS_CACHE'),
    ANALYTICS_TREND: kvStore('ANALYTICS_TREND'),
    MEDIA_BUCKET: r2Store('MEDIA_BUCKET'),
    HLS_CACHE: r2Store('HLS_CACHE'),
    RATE_LIMITER: rateLimiterStub,
    ANALYTICS_QUEUE: queueStub,
    CLOUD_ORIGIN: 'http://127.0.0.1:4000',
    EDGE_ENV: 'test',
  };

  const svc = (worker: EdgeWorker): ServiceBindingLike => ({
    fetch: async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
      const req = input instanceof Request ? input : new Request(input, init);
      const ctx = new HarnessCtx();
      serviceCtxPool.push(ctx);
      return await worker.fetch(req, env, ctx);
    },
  });

  env.SVC_SEARCH = svc(searchWorker);
  env.SVC_AI = svc(aiWorker);
  env.SVC_AUTH = svc(authWorker);
  env.SVC_PLAYER = svc(playerWorker);
  env.SVC_ANALYTICS = svc(analyticsWorker);

  Object.assign(env, opts.env ?? {});
  for (const name of opts.without ?? []) {
    delete (env as unknown as Record<string, unknown>)[name];
  }
  return env;
}

/* ------------------------------------------------------- request helpers ---- */

const EDGE_BASE = 'https://edge.animaxia.test';

export async function callWorker(
  worker: EdgeWorker,
  request: Request,
  env: EdgeEnv,
): Promise<{ response: Response; ctx: HarnessCtx }> {
  const ctx = new HarnessCtx();
  const response = await worker.fetch(request, env, ctx);
  return { response, ctx };
}

/** Invoke the gateway (the full pipeline) with a fresh collectible ctx. */
export async function edgeFetch(
  env: EdgeEnv,
  path: string,
  init?: RequestInit,
): Promise<{ response: Response; ctx: HarnessCtx }> {
  return callWorker(gatewayWorker, new Request(`${EDGE_BASE}${path}`, init), env);
}

/** Drive a Cloudflare Queues consumer batch through a worker. */
export async function consumeQueue(worker: EdgeWorker, env: EdgeEnv, messages: unknown[]): Promise<void> {
  const batch: QueueBatch = {
    messages: messages.map((body, i) => ({ body, id: `m${i}`, timestamp: Date.now(), attempts: 1 })),
    ackAll: () => undefined,
    retryAll: () => undefined,
    ack: () => undefined,
    retry: () => undefined,
  };
  const ctx = new HarnessCtx();
  await worker.queue?.(batch, env, ctx);
  await ctx.flush();
}

/* ------------------------------------------------------------ reset all ----- */

export function resetHarness(): void {
  for (const kv of kvStores.values()) kv.clear();
  for (const r2 of r2Stores.values()) r2.clear();
  memCache.clear();
  queueStub.clear();
  rateLimiterStub.reset();
  serviceCtxPool.length = 0;
  resetConfigCache();
  resetSecretCache();
  resetMemoryRateLimits();
  resetEdgeMetrics(); // FAZA 9 ops: isolate metrics counters between scenarios
}

/* -------------------------------------------------------- fetch stubbing ---- */

export interface StubRequest {
  url: URL;
  method: string;
  headers: Headers;
  bodyText: () => Promise<string>;
}

export type StubHandler = (req: StubRequest) => Response | Promise<Response>;

/**
 * Route selected hosts to test handlers; every other host gets a hermetic
 * 502 (tests must never touch the real network by accident). Returns a
 * restore function.
 */
export function installFetchStub(handlers: Record<string, StubHandler>): () => void {
  const originalFetch = globalThis.fetch.bind(globalThis);
  globalThis.fetch = (async (input: unknown, init?: RequestInit): Promise<Response> => {
    let url: URL;
    let method: string;
    let headers: Headers;
    let bodySource: BodyInit | null | undefined;
    if (input instanceof Request) {
      url = new URL(input.url);
      method = input.method;
      headers = input.headers;
      bodySource = input.body;
    } else {
      url = new URL(String(input));
      method = (init?.method as string) || 'GET';
      headers = new Headers(init?.headers as HeadersInit | undefined);
      bodySource = init?.body as BodyInit | null | undefined;
    }
    const handler = handlers[url.hostname] ?? handlers[url.host];
    if (handler) {
      let bodyUsed = false;
      const bodyText = async (): Promise<string> => {
        if (bodyUsed) return '';
        bodyUsed = true;
        if (bodySource == null) return '';
        if (typeof bodySource === 'string') return bodySource;
        if (bodySource instanceof ArrayBuffer) return new TextDecoder().decode(bodySource);
        return await new Response(bodySource).text();
      };
      return await handler({ url, method, headers, bodyText });
    }
    return new Response(JSON.stringify({ error: 'harness_unstubbed_host', host: url.hostname }), {
      status: 502,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    });
  }) as typeof fetch;
  return () => {
    globalThis.fetch = originalFetch;
  };
}

/** Expose a MemCache as globalThis.caches.default (shared/cache.ts L1 tier). */
export function installCaches(cache: CacheApiLike): () => void {
  const g = globalThis as unknown as { caches?: { default?: unknown } };
  const previous = g.caches;
  g.caches = { default: cache };
  return () => {
    if (previous === undefined) delete g.caches;
    else g.caches = previous;
  };
}
