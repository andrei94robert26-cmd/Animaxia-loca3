# Animaxia — Full-Stack Streaming Platform (Backend + Frontend)

Animaxia is an enterprise streaming platform for anime, movies, TV, sports and
news — with user accounts, premium subscriptions, social features, an AI hub,
analytics, an OpenSearch-style engine, background workers and a mobile API.

This archive contains the complete platform:

```
animaxia-platform/
├── backend/    Node.js + Express + Neon PostgreSQL (port 4000)
└── frontend/   Next.js 16 single-page app (port 3000)
```

---

## 1. Requirements

- [Bun](https://bun.sh) (recommended) or Node.js 20+
- A PostgreSQL database (Neon or any Postgres) — the connection string lives
  in `backend/.env` as `DATABASEURL`

## 2. Backend

```bash
cd backend
bun install          # or: npm install
bun run dev          # or: npm start   → http://localhost:4000
```

- The `.env` file ships with the Neon PostgreSQL connection string, TMDB /
  Jikan / YouTube / Football-Data / RSS provider keys and all platform
  settings — edit it to match your own credentials.
- On boot the backend creates every table it needs (content, users, tokens,
  watchlist, history, comments, votes, likes, views, subscriptions, audit
  logs, AI chats) and seeds the library when the database is empty.
- If PostgreSQL is unreachable the backend automatically falls back to a
  local JSON store and keeps probing for reconnection.

API overview (all JSON):

| Area | Endpoints |
| --- | --- |
| Core | `/api/health`, `/api/all`, `/api/content/:id`, `/api/content/:id/player`, `/api/miner`, `/api/admin/seed` |
| Providers | `/api/anime/*`, `/api/movies/*`, `/api/tv/*`, `/api/sports/*`, `/api/news` |
| Auth | `POST /api/auth/register\|login\|refresh\|logout`, `GET /api/auth/me` |
| Users | `/api/users/me`, `/api/users/me/watchlist`, `/api/users/me/history`, `/api/users/me/preferences`, `/api/users/me/avatar` |
| Premium | `/api/premium/plans\|me\|verify\|checkout\|confirm\|cancel` (Stripe sandbox) |
| Social | `/api/social/content/:id/comments`, `/api/social/content/:id/like`, `/api/social/feed/global\|personal` |
| AI | `/api/ai/recommendations`, `/api/ai/summarize`, `/api/ai/describe`, `/api/ai/chat`, `/api/ai/status` |
| Analytics | `/api/analytics/views`, `/api/analytics/trending`, `/api/analytics/user/:id`, `/api/analytics/overview` |
| Search | `/api/search/advanced`, `/api/search/autocomplete`, `/api/search/index`, `/api/search/status` |
| Cache | `/api/cache/stats`, `/api/cache/invalidate` |
| Workers | `/api/workers/mine\|prefetch\|thumbnails\|refresh\|jobs\|status` |
| Security | `/api/security/status`, `/api/security/audit` |
| Mobile | `/api/mobile/home\|player/:id\|profile\|config` |

## 3. Frontend

```bash
cd frontend
bun install          # or: npm install
bun run dev          # → http://localhost:3000
```

The frontend is a single-route Next.js app (hash-routed views: home,
category, franchise, content, player, search, recommendations, admin, auth,
profile, premium, feed, AI hub, mobile). Start the **backend first** — the
frontend proxies `/api/*` to `localhost:4000` automatically (configure with
`ANIMAXIA_BACKEND_PORT`; the `?XTransformPort=4000` query parameter is
accepted and ignored when the built-in proxy is used).

Sign in with any account you create at `#/auth` — the **first registered
account becomes the platform admin** (or list admin e-mails in the backend
`ADMINEMAILS` env var). A demo admin ships in the seeded database state:
`admin@animaxia.test` / `SuperSecret1` (change or remove it in production).

## 4. Highlights

- **Auth** — JWT access tokens (15 min) + rotating refresh tokens (30 days),
  scrypt password hashing, brute-force lockout, audit trail.
- **Premium** — free / plus / pro plans with per-plan limits (watchlist,
  history, AI quota, stream quality) and a Stripe sandbox checkout; set
  `STRIPESECRETKEY` to switch to live Stripe.
- **Social** — threaded comments, likes/dislikes, global and personalized
  activity feeds.
- **AI hub** — LLM recommendations, summaries, description generation and
  per-title chat (z-ai SDK, with heuristic fallbacks).
- **Analytics** — view/play events, trending, per-user stats and an admin
  dashboard with charts.
- **Search engine** — local OpenSearch-style engine: BM25 scoring, fuzzy
  matching (Levenshtein), autocomplete, field filters, auto re-indexing.
- **Workers** — worker threads for async mining, player prefetching, SVG
  thumbnail generation and periodic TMDB/Jikan catalog refresh (every 30
  minutes by default, `WORKERSREFRESHMS` to change, `0` to disable).
- **Mobile API** — dedicated BFF endpoints for a native app.

## 5. Production notes

- Set `NODE_ENV=production`, a strong `AUTHSECRET`, and your own
  `DATABASEURL` / provider keys in `backend/.env`.
- Serve the frontend behind the same origin as `/api` (the built-in Next
  rewrites already do this for `next start`).
- The Stripe integration runs in sandbox mode until a real `STRIPESECRETKEY`
  is provided.
