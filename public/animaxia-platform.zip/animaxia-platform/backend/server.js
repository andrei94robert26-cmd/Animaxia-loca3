/**
 * server.js — Animaxia backend composition root: Express app, middleware stack,
 * module routers, core content/health/miner routes, DB boot + seeding,
 * graceful shutdown. Listens on PORT (default 4000).
 */

import 'dotenv/config';
import express from 'express';
import cors from 'cors';

import { initDb, listContent, getContentById, getContentByExternalId, upsertContent, deleteContent, countContent, countsByType, driverInfo, closeDb } from './db.js';
import { cache, cacheMiddleware } from './cache.js';
import { rateLimitMiddleware, rateLimitStats } from './rateLimit.js';
import { logger, requestLogger } from './utils/logger.js';
import { breakerStats } from './utils/fetcher.js';
import { mineUrl } from './miner.js';
import { seed } from './seed.js';
import { playerAllowedTypes, resolvePlayer } from './modules/player/player.js';
import animeRouter from './modules/anime/jikan.js';
import { moviesRouter, tvRouter } from './modules/movies/tmdb.js';
import tvmazeRouter from './modules/tv/tvmaze.js';
import footballRouter from './modules/sports/football.js';
import f1Router from './modules/sports/f1.js';
import newsRouter from './modules/news/rss.js';

/* Phase-2 platform modules (users, premium, social, ai, analytics, search, cache, workers, security, mobile) */
import { ensurePlatformSchema } from './modules/platform/migrations.js';
import { events } from './modules/platform/events.js';
import { authRouter, attachUser, requireAuth, requireAdmin } from './modules/users/auth.js';
import { securityRouter, auditLog, clientIpOf } from './modules/security/security.js';
import profileRouter from './modules/users/profile.js';
import { plansRouter } from './modules/premium/plans.js';
import stripeRouter from './modules/premium/stripe.js';
import { commentsRouter } from './modules/social/comments.js';
import { feedRouter } from './modules/social/feed.js';
import aiRouter from './modules/ai/ai.js';
import analyticsRouter from './modules/analytics/analytics.js';
import searchRouter from './modules/search/search.js';
import advancedCacheRouter from './modules/cache/advancedCache.js';
import workersRouter from './modules/workers/workers.js';
import mobileRouter from './modules/mobile/mobile.js';

const PORT = parseInt(process.env.PORT || '4000', 10);
const VERSION = '1.0.0';
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function safeDecode(value) {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

function localFallbackWarning() {
  return driverInfo().driver === 'local-fallback'
    ? { warning: 'PostgreSQL credentials rejected — serving from local fallback store' }
    : {};
}

/** Invalidate cached HTTP responses after any data mutation (provider cache stays warm).
 *  Also notifies platform modules (search index, advanced cache) via the event bus. */
function invalidateHttpCache() {
  cache.clearPrefix('http:');
  events.emit('content:changed');
}

const app = express();
app.set('trust proxy', 1);
app.use(
  cors({
    origin: (origin, cb) => cb(null, !origin || origin === process.env.CORS_ORIGIN || true),
  }),
);
app.use(express.json({ limit: '2mb' })); // 2mb: avatar data-URL uploads
app.use(requestLogger);
app.use(rateLimitMiddleware);
app.use(attachUser); // req.user (from Bearer token) available platform-wide

app.get('/', (req, res) => {
  res.json({
    service: 'animaxia-backend',
    version: VERSION,
    status: 'ok',
    docs: 'Try /api/health',
  });
});

/* ------------------------------- module routers ------------------------------ */

app.use('/api/anime', cacheMiddleware(), animeRouter);
app.use('/api/movies', cacheMiddleware(), moviesRouter);
// TVmaze's /schedule must be registered before the TMDB tv router so the paths coexist.
app.use('/api/tv', cacheMiddleware(), tvmazeRouter, tvRouter);
app.use('/api/sports/football', cacheMiddleware(), footballRouter);
app.use('/api/sports/f1', cacheMiddleware(), f1Router);
app.use('/api/news', cacheMiddleware(), newsRouter);

/* ---------------------------- platform (Phase 2) ---------------------------- */

app.use('/api/auth', authRouter);
app.use('/api/users', requireAuth, profileRouter);
app.use('/api/premium', plansRouter, stripeRouter);
app.use('/api/social', commentsRouter, feedRouter);
app.use('/api/ai', aiRouter);
app.use('/api/analytics', analyticsRouter);
app.use('/api/search', searchRouter);
app.use('/api/cache', advancedCacheRouter);
app.use('/api/workers', workersRouter);
app.use('/api/security', requireAuth, requireAdmin, securityRouter);
app.use('/api/mobile', mobileRouter);

/* -------------------------------- core routes -------------------------------- */

app.get(
  '/api/health',
  wrap(async (req, res) => {
    const [totalItems, byType] = await Promise.all([countContent(), countsByType()]);
    res.json({
      status: 'ok',
      service: 'animaxia-backend',
      version: VERSION,
      env: process.env.NODE_ENV || 'development',
      uptimeSec: Math.floor(process.uptime()),
      timestamp: new Date().toISOString(),
      db: { ...driverInfo(), totalItems, countsByType: byType },
      cache: { ...cache.stats(), enabled: true, ttlMs: parseInt(process.env.CACHETTLMS || '60000', 10) },
      rateLimit: rateLimitStats(),
      providers: breakerStats(),
      player: { allowedTypes: playerAllowedTypes() },
    });
  }),
);

app.get(
  '/api/all',
  cacheMiddleware(),
  wrap(async (req, res) => {
    const result = await listContent({
      page: parseInt(req.query.page, 10) || 1,
      limit: parseInt(req.query.limit, 10) || 20,
      type: req.query.type || undefined,
      search: req.query.search || undefined,
      sort: req.query.sort === 'title' ? 'title' : 'createdat',
    });
    res.status(200).json({ ...result, ...localFallbackWarning() });
  }),
);

app.get(
  '/api/content/external/:externalid',
  cacheMiddleware(),
  wrap(async (req, res) => {
    const row = await getContentByExternalId(safeDecode(req.params.externalid));
    if (!row) return res.status(404).json({ error: 'Content not found' });
    return res.json(row);
  }),
);

app.get(
  '/api/content/:id',
  cacheMiddleware(),
  wrap(async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ error: 'Invalid content id' });
    }
    const row = await getContentById(id);
    if (!row) return res.status(404).json({ error: 'Content not found' });
    return res.json(row);
  }),
);

app.delete(
  '/api/content/:id',
  wrap(async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ error: 'Invalid content id' });
    }
    const deleted = await deleteContent(id);
    if (!deleted) return res.status(404).json({ error: 'Content not found' });
    invalidateHttpCache();
    await auditLog({ userid: req.user?.id ?? null, action: 'content.delete', ip: clientIpOf(req), meta: { id, title: deleted.title } });
    return res.json({ ok: true, deleted });
  }),
);

app.post(
  '/api/content',
  wrap(async (req, res) => {
    const { externalid, type, title, thumbnail, metadata } = req.body || {};
    if (!externalid || !title) {
      return res.status(400).json({ error: 'Missing required fields: externalid, title' });
    }
    const { record, created } = await upsertContent({ externalid, type, title, thumbnail, metadata });
    invalidateHttpCache();
    await auditLog({ userid: req.user?.id ?? null, action: created ? 'content.create' : 'content.update', ip: clientIpOf(req), meta: { id: record.id, externalid } });
    return res.json({ ok: true, record, created });
  }),
);

app.get(
  '/api/content/:id/player',
  cacheMiddleware(),
  wrap(async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ error: 'Invalid content id' });
    }
    const content = await getContentById(id);
    if (!content) return res.status(404).json({ error: 'Content not found' });
    const resolved = await resolvePlayer(content);
    return res.json(resolved);
  }),
);

async function handleMine(req, res) {
  const url = req.method === 'GET' ? req.query.url : req.body?.url;
  if (!url || typeof url !== 'string') {
    return res.status(400).json({ error: 'Missing url' });
  }
  const options =
    req.method === 'GET'
      ? { type: req.query.type, externalId: req.query.externalId }
      : { type: req.body?.type, externalId: req.body?.externalId };
  try {
    const { extraction, record } = await mineUrl(url, options);
    invalidateHttpCache();
    await auditLog({ userid: req.user?.id ?? null, action: 'miner.run', ip: clientIpOf(req), meta: { url, id: record?.id } });
    return res.json({ ok: true, extraction, record });
  } catch (err) {
    return res.status(err.status || 502).json({ error: err.message || 'Mining failed' });
  }
}

// GET /api/miner also UPSERTs (explicitly uncached — every call re-mines and re-upserts).
app.get('/api/miner', wrap(handleMine));
app.post('/api/miner', wrap(handleMine));

app.post(
  '/api/admin/seed',
  wrap(async (req, res) => {
    const result = await seed();
    invalidateHttpCache();
    await auditLog({ userid: req.user?.id ?? null, action: 'admin.seed', ip: clientIpOf(req), meta: { added: result.added } });
    return res.json({ ok: true, ...result });
  }),
);

/* ------------------------------ error handling ------------------------------ */

app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const status = err.status || 500;
  logger.error(`[error] ${req.method} ${req.originalUrl} → ${status}: ${err.message}`);
  res.status(status).json({ error: err.message || 'Internal server error' });
});

/* ---------------------------------- boot ------------------------------------ */

async function main() {
  await initDb();

  // Phase-2 platform schema (users, tokens, watchlist, history, comments,
  // votes, likes, views, subscriptions, audit logs, ai chats) — idempotent.
  try {
    await ensurePlatformSchema();
  } catch (err) {
    logger.error(`[boot] Platform schema migration failed (platform modules will answer 503): ${err.message}`);
  }

  try {
    const count = await countContent();
    if (count === 0) {
      logger.info('[boot] Empty database — seeding initial content…');
      const result = await seed();
      logger.info(
        `[boot] Seeded demo:${result.added.demo} movie:${result.added.movie} tv:${result.added.tv} anime:${result.added.anime} (animeSource=${result.animeSource}, totalItems=${result.totalItems})`,
      );
    } else {
      logger.info(`[boot] Database already has ${count} items — skipping seed`);
    }
  } catch (err) {
    logger.error(`[boot] Seeding failed (non-fatal): ${err.message}`);
  }

  const info = driverInfo();
  const server = app.listen(PORT, () => {
    logger.info('============================================================');
    logger.info(`  ANIMAXIA BACKEND v${VERSION} — listening on http://localhost:${PORT}`);
    logger.info(`  DB driver: ${info.driver} (connected: ${info.connected})`);
    logger.info(`  Env: ${process.env.NODE_ENV || 'development'} · Cache TTL: ${process.env.CACHETTLMS}ms`);
    logger.info('============================================================');
  });

  const shutdown = async (signal) => {
    logger.info(`[shutdown] ${signal} received — closing server`);
    server.close(async () => {
      await closeDb();
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 5000).unref();
  };

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('unhandledRejection', (reason) => {
    logger.error(`[process] Unhandled rejection: ${reason instanceof Error ? reason.stack || reason.message : reason}`);
  });
  process.on('uncaughtException', (err) => {
    logger.error(`[process] Uncaught exception: ${err instanceof Error ? err.stack || err.message : err}`);
  });
}

main().catch((err) => {
  logger.error(`[boot] Fatal startup error: ${err.stack || err.message}`);
  process.exit(1);
});
