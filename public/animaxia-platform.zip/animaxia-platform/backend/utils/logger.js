/**
 * utils/logger.js — Leveled colorized console logger with ISO timestamps.
 * Exports `logger` (debug/info/warn/error) and `requestLogger` Express middleware
 * that logs `METHOD /path STATUS 123ms ip` on response finish.
 * Colors: gray(dim) reset, green, yellow, red, cyan via ANSI escape codes.
 */

const COLORS = {
  reset: '\x1b[0m',
  dim: '\x1b[2m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m',
};

const LEVEL_COLORS = {
  DEBUG: COLORS.dim,
  INFO: COLORS.green,
  WARN: COLORS.yellow,
  ERROR: COLORS.red,
};

function timestamp() {
  return new Date().toISOString();
}

function write(level, message) {
  const color = LEVEL_COLORS[level] || COLORS.reset;
  const prefix = `[${timestamp()}] [${level}]`;
  if (level === 'ERROR') {
    console.error(`${color}${prefix}${COLORS.reset} ${message}`);
  } else if (level === 'WARN') {
    console.warn(`${color}${prefix}${COLORS.reset} ${message}`);
  } else {
    console.log(`${color}${prefix}${COLORS.reset} ${message}`);
  }
}

export const logger = {
  debug(message, ...args) {
    if (process.env.NODE_ENV === 'development') {
      write('DEBUG', args.length ? `${message} ${args.map(String).join(' ')}` : message);
    }
  },
  info(message, ...args) {
    write('INFO', args.length ? `${message} ${args.map(String).join(' ')}` : message);
  },
  warn(message, ...args) {
    write('WARN', args.length ? `${message} ${args.map(String).join(' ')}` : message);
  },
  error(message, ...args) {
    write('ERROR', args.length ? `${message} ${args.map(String).join(' ')}` : message);
  },
};

function statusColor(status) {
  if (status >= 500) return COLORS.red;
  if (status >= 400) return COLORS.yellow;
  if (status >= 300) return COLORS.cyan;
  return COLORS.green;
}

export function requestLogger(req, res, next) {
  const start = Date.now();
  res.on('finish', () => {
    const elapsed = Date.now() - start;
    const status = res.statusCode;
    const ip =
      (req.headers['x-forwarded-for'] && String(req.headers['x-forwarded-for']).split(',')[0].trim()) ||
      req.headers['x-real-ip'] ||
      (req.socket && req.socket.remoteAddress) ||
      '-';
    const line = `${req.method} ${req.originalUrl} ${status} ${elapsed}ms ${ip}`;
    console.log(`${statusColor(status)}[${timestamp()}] [REQ]${COLORS.reset} ${line}`);
  });
  next();
}
