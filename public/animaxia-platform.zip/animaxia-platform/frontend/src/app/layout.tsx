import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Animaxia — Stream Anime, Movies, TV & More",
  description:
    "Animaxia is a full-stack streaming platform: anime, movies, TV shows, sports and news powered by an enterprise Express + Neon PostgreSQL backend with a built-in stream miner.",
  keywords: ["Animaxia", "anime", "movies", "TV", "streaming", "player", "sports", "news"],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Animaxia — Stream Everything",
    description: "Anime, movies, TV, sports and news on one platform.",
    siteName: "Animaxia",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#0a0a10",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-[#0a0a10] text-zinc-100`}
      >
        {children}
      </body>
    </html>
  );
}
