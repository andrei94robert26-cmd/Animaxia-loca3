'use client';

/**
 * page.tsx — Animaxia single-route SPA shell. All "pages" are hash-routed
 * views (see src/lib/animaxia/router.ts). This is the only Next.js route.
 */

import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Play } from 'lucide-react';
import { Toaster } from '@/components/ui/sonner';
import { AuthProvider } from '@/components/animaxia/auth-provider';
import { Navbar } from '@/components/animaxia/navbar';
import { Footer } from '@/components/animaxia/footer';
import { navigate, useRoute, type AppRoute } from '@/lib/animaxia/router';
import { HomeView } from '@/components/animaxia/views/home-view';
import { CategoryView } from '@/components/animaxia/views/category-view';
import { FranchiseView } from '@/components/animaxia/views/franchise-view';
import { ContentView } from '@/components/animaxia/views/content-view';
import { PlayerView } from '@/components/animaxia/views/player-view';
import { SearchView } from '@/components/animaxia/views/search-view';
import { RecommendationsView } from '@/components/animaxia/views/recommendations-view';
import { AdminView } from '@/components/animaxia/views/admin-view';
import { AuthView } from '@/components/animaxia/views/auth-view';
import { ProfileView } from '@/components/animaxia/views/profile-view';
import { PremiumView } from '@/components/animaxia/views/premium-view';
import { FeedView } from '@/components/animaxia/views/feed-view';
import { AiView } from '@/components/animaxia/views/ai-view';
import { MobileView } from '@/components/animaxia/views/mobile-view';
import { Button } from '@/components/ui/button';

function renderView(route: AppRoute) {
  switch (route.view) {
    case 'home':
      return <HomeView />;
    case 'category':
      return <CategoryView route={route} />;
    case 'franchise':
      return <FranchiseView route={route} />;
    case 'content':
      return <ContentView route={route} />;
    case 'player':
      return <PlayerView route={route} />;
    case 'search':
      return <SearchView route={route} />;
    case 'recommendations':
      return <RecommendationsView />;
    case 'admin':
      return <AdminView />;
    case 'auth':
      return <AuthView route={route} />;
    case 'profile':
      return <ProfileView route={route} />;
    case 'premium':
      return <PremiumView route={route} />;
    case 'feed':
      return <FeedView route={route} />;
    case 'ai':
      return <AiView route={route} />;
    case 'mobile':
      return <MobileView route={route} />;
    default:
      return (
        <div className="mx-auto flex min-h-[50vh] w-full max-w-7xl flex-col items-center justify-center gap-4 px-4 text-center">
          <h1 className="text-3xl font-black text-white">404 — Lost in the stream</h1>
          <p className="text-sm text-zinc-400">The page you are looking for does not exist.</p>
          <Button onClick={() => navigate('/home')} className="bg-rose-600 font-bold hover:bg-rose-500">
            Back to home
          </Button>
        </div>
      );
  }
}

function Splash() {
  return (
    <div className="fixed inset-0 z-[100] grid place-items-center bg-[#0a0a10]">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col items-center gap-4"
      >
        <motion.span
          animate={{ scale: [1, 1.08, 1] }}
          transition={{ repeat: Infinity, duration: 1.4, ease: 'easeInOut' }}
          className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-rose-500 to-fuchsia-600 shadow-2xl shadow-rose-900/50"
        >
          <Play className="h-7 w-7 fill-white text-white" aria-hidden />
        </motion.span>
        <span className="text-2xl font-black tracking-tight text-white">
          ANIMA<span className="text-rose-400">XIA</span>
        </span>
      </motion.div>
    </div>
  );
}

export default function Page() {
  const route = useRoute();

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [route?.view, route?.params.join('/')]);

  return (
    <div className="relative flex min-h-screen flex-col bg-[#0a0a10] text-zinc-100">
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-32 right-0 h-96 w-96 rounded-full bg-rose-600/10 blur-3xl" />
        <div className="absolute left-0 top-1/3 h-96 w-96 rounded-full bg-fuchsia-600/[0.07] blur-3xl" />
        <div className="absolute bottom-0 right-1/4 h-72 w-72 rounded-full bg-orange-600/[0.05] blur-3xl" />
      </div>

      {route ? (
        <AuthProvider>
          <Navbar route={route} />
          <main id="main" className="flex-1">
            {renderView(route)}
          </main>
          <Footer />
        </AuthProvider>
      ) : (
        <Splash />
      )}

      <Toaster theme="dark" position="bottom-right" richColors closeButton />
    </div>
  );
}
