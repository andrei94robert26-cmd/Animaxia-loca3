'use client';

/**
 * content-ai-panel.tsx — "AI assistant" panel for a library title: AI summary
 * (aiSummarize) + a compact content-scoped chat (aiChat). Auth-gated chat with
 * plan-quota (402) upgrade card. Anonymous summaries are allowed (5/day).
 */

import { useEffect, useRef, useState } from 'react';
import { Crown, Loader2, Send, Sparkles, Zap } from 'lucide-react';
import { toast } from 'sonner';
import { platform, PlatformError } from '@/lib/animaxia/platform';
import { navigate } from '@/lib/animaxia/router';
import { useAuth } from '@/components/animaxia/auth-provider';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { ErrorState } from './states';

/* ------------------------------- local helpers ------------------------------ */

interface ChatMessage {
  role: 'user' | 'ai';
  text: string;
}

/** Renders an AI text: bullet lines ("- " / "• ") become styled list items. */
function SummaryText({ text }: { text: string }) {
  const lines = text
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);
  return (
    <div className="space-y-2.5">
      {lines.map((line, i) => {
        if (line.startsWith('- ') || line.startsWith('• ')) {
          return (
            <div key={i} className="flex gap-2.5">
              <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full bg-rose-400" aria-hidden />
              <p className="text-sm leading-relaxed text-zinc-300">{line.slice(2)}</p>
            </div>
          );
        }
        return (
          <p key={i} className="text-sm leading-relaxed text-zinc-300">
            {line}
          </p>
        );
      })}
    </div>
  );
}

function ProviderBadge({ provider }: { provider: string }) {
  const isLlm = provider === 'z-ai';
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider',
        isLlm ? 'border-rose-500/30 bg-rose-500/10 text-rose-300' : 'border-amber-500/30 bg-amber-500/10 text-amber-300',
      )}
    >
      {isLlm ? <Sparkles className="h-3 w-3" aria-hidden /> : <Zap className="h-3 w-3" aria-hidden />}
      {provider}
    </span>
  );
}

function TypingDots() {
  return (
    <span className="inline-flex items-center gap-1 py-1" role="status" aria-label="AI is thinking">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="h-1.5 w-1.5 animate-bounce rounded-full bg-rose-300"
          style={{ animationDelay: `${i * 150}ms` }}
        />
      ))}
    </span>
  );
}

function UpgradeCard({ message, compact }: { message: string; compact?: boolean }) {
  return (
    <div className="rounded-xl border border-amber-500/30 bg-amber-500/[0.07] p-4 text-sm">
      <p className="flex items-center gap-2 font-semibold text-amber-300">
        <Crown className="h-4 w-4 shrink-0" aria-hidden />
        Daily AI limit reached
      </p>
      <p className="mt-1 text-xs leading-relaxed text-zinc-400">{message}</p>
      <Button
        type="button"
        size="sm"
        className={cn('mt-3 bg-rose-600 font-bold text-white hover:bg-rose-500', compact && 'mt-2')}
        onClick={() => navigate('/premium')}
      >
        <Crown aria-hidden /> Upgrade plan
      </Button>
    </div>
  );
}

/* ---------------------------------- panel ---------------------------------- */

export function ContentAiPanel({ contentId, title }: { contentId: number; title: string }) {
  const [tab, setTab] = useState<'summary' | 'chat'>('summary');

  return (
    <Card id="ai-assistant" className="h-fit border-white/10 bg-white/[0.03]">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2.5 text-sm font-bold uppercase tracking-widest text-zinc-400">
          <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-rose-500/30 to-fuchsia-500/30">
            <Sparkles className="h-4 w-4 text-rose-300" aria-hidden />
          </span>
          AI assistant
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={tab} onValueChange={(v) => setTab(v as 'summary' | 'chat')}>
          <TabsList className="h-10 w-full rounded-xl border border-white/10 bg-white/[0.03] p-1">
            <TabsTrigger
              value="summary"
              className="rounded-lg px-4 text-zinc-400 hover:text-zinc-100 data-[state=active]:bg-rose-600 data-[state=active]:text-white"
            >
              Summary
            </TabsTrigger>
            <TabsTrigger
              value="chat"
              className="rounded-lg px-4 text-zinc-400 hover:text-zinc-100 data-[state=active]:bg-rose-600 data-[state=active]:text-white"
            >
              Ask AI
            </TabsTrigger>
          </TabsList>
          <TabsContent value="summary" className="pt-4">
            <SummaryPane contentId={contentId} title={title} />
          </TabsContent>
          <TabsContent value="chat" className="pt-4">
            <ChatPane contentId={contentId} title={title} />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

/* ------------------------------- summary pane ------------------------------- */

function SummaryPane({ contentId, title }: { contentId: number; title: string }) {
  const [result, setResult] = useState<{ summary: string; provider: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function summarize() {
    if (loading) return;
    setLoading(true);
    setError(null);
    try {
      const res = await platform.aiSummarize(contentId);
      setResult({ summary: res.summary, provider: res.provider });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not generate a summary');
    } finally {
      setLoading(false);
    }
  }

  async function copy() {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result.summary);
      toast.success('Summary copied to clipboard');
    } catch {
      toast.error('Clipboard is not available in this browser');
    }
  }

  if (loading) {
    return (
      <div className="space-y-2.5" aria-busy="true" aria-label="Generating summary">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-11/12" />
        <Skeleton className="h-4 w-4/5" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-2/3" />
      </div>
    );
  }

  if (error) {
    return <ErrorState compact message={error} onRetry={summarize} />;
  }

  if (!result) {
    return (
      <div className="space-y-3">
        <p className="text-sm leading-relaxed text-zinc-400">
          Generate a quick AI summary of <span className="font-semibold text-zinc-200">{title}</span> — perfect for a
          rapid catch-up before watching.
        </p>
        <Button
          type="button"
          onClick={summarize}
          className="w-full bg-rose-600 font-bold text-white hover:bg-rose-500"
        >
          <Sparkles aria-hidden /> Summarize this title
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <SummaryText text={result.summary} />
      <div className="flex items-center justify-between gap-3 border-t border-white/5 pt-3">
        <ProviderBadge provider={result.provider} />
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={copy}
          className="border-white/15 bg-white/5 font-semibold hover:bg-white/10"
        >
          Copy
        </Button>
      </div>
    </div>
  );
}

/* -------------------------------- chat pane -------------------------------- */

function ChatPane({ contentId, title }: { contentId: number; title: string }) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [quotaError, setQuotaError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, busy]);

  if (!user) {
    return (
      <div className="space-y-3 text-center">
        <p className="text-sm leading-relaxed text-zinc-400">
          Sign in to chat with the Animaxia AI about <span className="font-semibold text-zinc-200">{title}</span>.
        </p>
        <Button
          type="button"
          className="bg-rose-600 font-bold text-white hover:bg-rose-500"
          onClick={() => navigate('/auth')}
        >
          Sign in to chat
        </Button>
      </div>
    );
  }

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    setBusy(true);
    setQuotaError(null);
    setMessages((prev) => [...prev, { role: 'user', text }]);
    setInput('');
    try {
      const res = await platform.aiChat(contentId, text);
      setMessages((prev) => [...prev, { role: 'ai', text: res.reply }]);
    } catch (e) {
      if (e instanceof PlatformError && e.upgrade) {
        setQuotaError(e.message);
      } else {
        setMessages((prev) => [...prev, { role: 'ai', text: e instanceof Error ? e.message : 'Something went wrong.' }]);
      }
    } finally {
      setBusy(false);
    }
  }

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      void send();
    }
  };

  return (
    <div className="space-y-3">
      <div
        ref={scrollRef}
        className="custom-scrollbar max-h-96 space-y-3 overflow-y-auto rounded-xl border border-white/10 bg-black/20 p-3"
        aria-live="polite"
      >
        {messages.length === 0 && !busy && !quotaError && (
          <p className="py-6 text-center text-xs leading-relaxed text-zinc-500">
            Ask anything about <span className="font-semibold text-zinc-300">{title}</span> — characters, plot, where to
            start, similar vibes…
          </p>
        )}
        {messages.map((m, i) => (
          <div key={i} className={cn('flex gap-2', m.role === 'user' ? 'justify-end' : 'justify-start')}>
            {m.role === 'ai' && (
              <span className="mt-1 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-gradient-to-br from-rose-500/30 to-fuchsia-500/30">
                <Sparkles className="h-3 w-3 text-rose-300" aria-hidden />
              </span>
            )}
            <div
              className={cn(
                'max-w-[85%] whitespace-pre-wrap break-words px-3.5 py-2 text-sm leading-relaxed',
                m.role === 'user'
                  ? 'rounded-2xl rounded-br-sm bg-rose-600/20 text-rose-50'
                  : 'rounded-2xl rounded-bl-sm bg-white/5 text-zinc-200',
              )}
            >
              {m.text}
            </div>
          </div>
        ))}
        {busy && (
          <div className="flex justify-start">
            <span className="mt-1 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-gradient-to-br from-rose-500/30 to-fuchsia-500/30">
              <Sparkles className="h-3 w-3 text-rose-300" aria-hidden />
            </span>
            <div className="rounded-2xl rounded-bl-sm bg-white/5 px-3.5 py-2">
              <TypingDots />
            </div>
          </div>
        )}
      </div>

      {quotaError && <UpgradeCard message={quotaError} compact />}

      <div className="flex items-end gap-2">
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={`Ask about ${title}…`}
          aria-label={`Ask the AI about ${title}`}
          rows={2}
          maxLength={1000}
          className="min-h-11 flex-1 rounded-xl border-white/10 bg-white/[0.04] text-sm text-zinc-100 placeholder:text-zinc-500 focus-visible:border-rose-500/50 focus-visible:ring-rose-500/30"
        />
        <Button
          type="button"
          onClick={() => void send()}
          disabled={busy || !input.trim()}
          aria-label="Send message"
          className="h-11 bg-rose-600 font-bold text-white hover:bg-rose-500"
        >
          {busy ? <Loader2 className="animate-spin" aria-hidden /> : <Send aria-hidden />}
        </Button>
      </div>
      {messages.length > 0 && (
        <button
          type="button"
          onClick={() => {
            setMessages([]);
            setQuotaError(null);
          }}
          className="text-[11px] font-semibold text-zinc-500 transition hover:text-zinc-300"
        >
          Clear conversation
        </button>
      )}
    </div>
  );
}
