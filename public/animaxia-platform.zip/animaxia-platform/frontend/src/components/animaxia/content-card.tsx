'use client';

/**
 * content-card.tsx — Poster card used across all grids and rows.
 * Handles image fallback, badges, hover play affordance and navigation.
 */

import { useState } from 'react';
import { ExternalLink, Play } from 'lucide-react';
import { navigate, targetForItem } from '@/lib/animaxia/router';
import type { NormalizedItem } from '@/lib/animaxia/types';
import { BrandPlaceholder, RatingBadge, TypeBadge } from './states';
import { cn } from '@/lib/utils';

export function ContentCard({ item, className }: { item: NormalizedItem; className?: string }) {
  const [imgError, setImgError] = useState(false);
  const target = targetForItem(item);
  const showImage = Boolean(item.image) && !imgError;

  const body = (
    <>
      <div className="relative aspect-[2/3] w-full overflow-hidden rounded-xl border border-white/10 bg-white/[0.03] transition-colors duration-300 group-hover:border-rose-500/40">
        {showImage ? (
          <img
            src={item.image as string}
            alt={item.title}
            loading="lazy"
            onError={() => setImgError(true)}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <BrandPlaceholder title={item.title} />
        )}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent opacity-90" />
        <div className="absolute left-2 top-2 flex flex-col items-start gap-1">
          <RatingBadge value={item.rating} />
        </div>
        <div className="absolute right-2 top-2">
          <TypeBadge type={item.type} />
        </div>
        <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity duration-300 group-hover:opacity-100">
          <span className="rounded-full bg-rose-600/95 p-3 shadow-lg shadow-rose-900/40">
            {item.kind === 'link' ? (
              <ExternalLink className="h-5 w-5 fill-white text-white" aria-hidden />
            ) : (
              <Play className="h-5 w-5 fill-white text-white" aria-hidden />
            )}
          </span>
        </div>
        <div className="absolute inset-x-0 bottom-0 p-2.5">
          <p className="line-clamp-2 text-sm font-semibold leading-tight text-white drop-shadow">{item.title}</p>
          {item.year != null && item.year !== '' && (
            <p className="mt-0.5 text-[11px] text-zinc-400">{item.year}</p>
          )}
        </div>
      </div>
    </>
  );

  if (!target) {
    return (
      <div className={cn('group w-full', className)} aria-label={item.title}>
        {body}
      </div>
    );
  }

  if (target.kind === 'external') {
    return (
      <a
        href={target.href}
        target="_blank"
        rel="noopener noreferrer"
        className={cn('group w-full focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/60 rounded-xl', className)}
        aria-label={`${item.title} — opens external site`}
      >
        {body}
      </a>
    );
  }

  return (
    <button
      type="button"
      onClick={() => navigate(target.href)}
      className={cn('group w-full text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/60 rounded-xl', className)}
      aria-label={`Open ${item.title}`}
    >
      {body}
    </button>
  );
}
