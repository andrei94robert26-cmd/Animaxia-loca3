'use client';

/**
 * navbar.tsx — Sticky top navigation with brand, desktop links, quick search,
 * platform quick-links (Feed, AI hub), auth state (sign-in button or avatar
 * dropdown with profile/premium/admin/logout) and a mobile sheet menu.
 */

import { useState } from 'react';
import {
  Bookmark,
  Bot,
  Clapperboard,
  Crown,
  LogIn,
  LogOut,
  Rss,
  Search,
  ShieldCheck,
  Sparkles,
  Menu,
  MonitorPlay,
  Newspaper,
  Play,
  Sword,
  Trophy,
  Tv,
  UserRound,
  Film,
  Home,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { navigate, type AppRoute } from '@/lib/animaxia/router';
import { useAuth } from '@/components/animaxia/auth-provider';
import { cn } from '@/lib/utils';

interface NavLink {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  match: (route: AppRoute | null) => boolean;
}

const LINKS: NavLink[] = [
  { label: 'Home', href: '/home', icon: Home, match: (r) => !r || r.view === 'home' },
  {
    label: 'Movies',
    href: '/category/movie',
    icon: Film,
    match: (r) => r?.view === 'category' && r.params[0] === 'movie',
  },
  {
    label: 'TV',
    href: '/category/tv',
    icon: Tv,
    match: (r) => r?.view === 'category' && r.params[0] === 'tv',
  },
  {
    label: 'Anime',
    href: '/category/anime',
    icon: Sword,
    match: (r) => r?.view === 'category' && r.params[0] === 'anime',
  },
  {
    label: 'Sports',
    href: '/category/sports',
    icon: Trophy,
    match: (r) => r?.view === 'category' && r.params[0] === 'sports',
  },
  {
    label: 'News',
    href: '/category/news',
    icon: Newspaper,
    match: (r) => r?.view === 'category' && r.params[0] === 'news',
  },
  { label: 'Franchises', href: '/franchise', icon: Bookmark, match: (r) => r?.view === 'franchise' },
  {
    label: 'For You',
    href: '/recommendations',
    icon: Sparkles,
    match: (r) => r?.view === 'recommendations',
  },
];

/** Compact platform quick-links (icon buttons, all breakpoints). */
const QUICK_LINKS: { label: string; href: string; icon: React.ComponentType<{ className?: string }>; matchView: string }[] = [
  { label: 'Activity feed', href: '/feed', icon: Rss, matchView: 'feed' },
  { label: 'AI hub', href: '/ai', icon: Bot, matchView: 'ai' },
];

export function Navbar({ route }: { route: AppRoute | null }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const { user, initializing, isAdmin, logout } = useAuth();

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    navigate(q ? `/search?q=${encodeURIComponent(q)}` : '/search');
    setQuery('');
    setOpen(false);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/home');
  };

  const mobileExtraLinks: NavLink[] = [
    { label: 'Activity feed', href: '/feed', icon: Rss, match: (r) => r?.view === 'feed' },
    { label: 'AI hub', href: '/ai', icon: Bot, match: (r) => r?.view === 'ai' },
    { label: 'Premium plans', href: '/premium', icon: Crown, match: (r) => r?.view === 'premium' },
    ...(user
      ? [{ label: 'My profile', href: '/profile', icon: UserRound, match: (r: AppRoute | null) => r?.view === 'profile' }]
      : []),
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[#0a0a10]/85 backdrop-blur-xl">
      <nav aria-label="Main navigation" className="mx-auto flex h-16 w-full max-w-7xl items-center gap-3 px-4 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={() => navigate('/home')}
          className="flex items-center gap-2.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/60 rounded-lg"
          aria-label="Animaxia home"
        >
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-rose-500 to-fuchsia-600 shadow-lg shadow-rose-900/40">
            <Play className="h-4.5 w-4.5 fill-white text-white" aria-hidden />
          </span>
          <span className="flex flex-col items-start leading-none">
            <span className="text-lg font-black tracking-tight text-white">
              ANIMA<span className="text-rose-400">XIA</span>
            </span>
            <span className="hidden text-[10px] font-medium uppercase tracking-[0.2em] text-zinc-500 sm:block">
              Stream everything
            </span>
          </span>
        </button>

        <ul className="ml-4 hidden items-center gap-1 lg:flex">
          {LINKS.map((link) => {
            const active = link.match(route);
            const Icon = link.icon;
            return (
              <li key={link.href}>
                <button
                  type="button"
                  onClick={() => navigate(link.href)}
                  aria-current={active ? 'page' : undefined}
                  className={cn(
                    'flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition',
                    active ? 'bg-rose-500/15 text-rose-300' : 'text-zinc-400 hover:bg-white/5 hover:text-zinc-100',
                  )}
                >
                  <Icon className="h-4 w-4" aria-hidden />
                  {link.label}
                </button>
              </li>
            );
          })}
        </ul>

        <div className="ml-auto flex items-center gap-1.5">
          {QUICK_LINKS.map((quick) => {
            const Icon = quick.icon;
            const active = route?.view === quick.matchView;
            return (
              <Button
                key={quick.href}
                variant="ghost"
                size="icon"
                aria-label={quick.label}
                title={quick.label}
                onClick={() => navigate(quick.href)}
                className={cn(
                  'hidden text-zinc-400 hover:bg-white/5 hover:text-white sm:inline-flex',
                  active && 'bg-rose-500/15 text-rose-300',
                )}
              >
                <Icon className="h-5 w-5" aria-hidden />
              </Button>
            );
          })}

          <form onSubmit={submitSearch} className="hidden md:block" role="search">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" aria-hidden />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search titles…"
                aria-label="Search titles"
                className="h-9 w-44 border-white/10 bg-white/5 pl-9 text-sm text-zinc-100 placeholder:text-zinc-500 focus-visible:ring-rose-500/50 lg:w-56"
              />
            </div>
          </form>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Search"
            onClick={() => navigate('/search')}
            className="text-zinc-400 hover:bg-white/5 hover:text-white md:hidden"
          >
            <Search className="h-5 w-5" aria-hidden />
          </Button>

          {/* Auth area */}
          {initializing ? (
            <span className="ml-1 hidden h-8 w-8 animate-pulse rounded-full bg-white/10 sm:block" aria-hidden />
          ) : user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  type="button"
                  aria-label="Account menu"
                  className="ml-1 rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/60"
                >
                  <Avatar className="h-8 w-8 border border-white/15">
                    {user.avatar?.startsWith('data:') || user.avatar?.startsWith('http') || user.avatar?.startsWith('/') ? (
                      <AvatarImage src={user.avatar} alt={user.username} />
                    ) : null}
                    <AvatarFallback className="bg-gradient-to-br from-rose-500 to-fuchsia-600 text-xs font-black text-white">
                      {user.username.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52 border-white/10 bg-[#12121c] text-zinc-100">
                <DropdownMenuLabel className="flex flex-col gap-0.5">
                  <span className="text-sm font-bold">{user.username}</span>
                  <span className="flex items-center gap-1.5 text-xs font-normal text-zinc-400">
                    {user.plan !== 'free' && <Crown className="h-3 w-3 text-amber-400" aria-hidden />}
                    {user.plan === 'free' ? 'Free plan' : `${user.plan.charAt(0).toUpperCase()}${user.plan.slice(1)} plan`}
                    {isAdmin && <span className="rounded bg-rose-500/20 px-1 text-[10px] font-bold text-rose-300">ADMIN</span>}
                  </span>
                </DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-white/10" />
                <DropdownMenuItem onClick={() => navigate('/profile')} className="gap-2">
                  <UserRound className="h-4 w-4" aria-hidden /> My profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/premium')} className="gap-2">
                  <Crown className="h-4 w-4" aria-hidden /> Premium plans
                </DropdownMenuItem>
                {isAdmin && (
                  <DropdownMenuItem onClick={() => navigate('/admin')} className="gap-2">
                    <ShieldCheck className="h-4 w-4" aria-hidden /> Admin panel
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator className="bg-white/10" />
                <DropdownMenuItem onClick={handleLogout} className="gap-2 text-rose-400 focus:text-rose-300">
                  <LogOut className="h-4 w-4" aria-hidden /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button
              onClick={() => navigate('/auth')}
              className="ml-1 hidden bg-rose-600 font-bold hover:bg-rose-500 sm:inline-flex"
              size="sm"
            >
              <LogIn className="mr-1.5 h-4 w-4" aria-hidden />
              Sign in
            </Button>
          )}

          <Button
            variant="ghost"
            size="icon"
            aria-label="Admin panel"
            onClick={() => navigate('/admin')}
            className={cn(
              'hidden text-zinc-400 hover:bg-white/5 hover:text-white lg:inline-flex',
              route?.view === 'admin' && 'bg-rose-500/15 text-rose-300',
            )}
          >
            <ShieldCheck className="h-5 w-5" aria-hidden />
          </Button>

          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                aria-label="Open menu"
                className="text-zinc-300 hover:bg-white/5 hover:text-white lg:hidden"
              >
                <Menu className="h-5 w-5" aria-hidden />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 border-white/10 bg-[#0d0d14] text-zinc-100">
              <SheetTitle className="flex items-center gap-2 px-1 text-base font-black tracking-tight">
                <Clapperboard className="h-5 w-5 text-rose-400" aria-hidden />
                ANIMAXIA
              </SheetTitle>
              <nav aria-label="Mobile navigation" className="mt-2 flex flex-col">
                <form onSubmit={submitSearch} className="mb-3 px-3" role="search">
                  <div className="relative">
                    <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" aria-hidden />
                    <Input
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Search titles…"
                      aria-label="Search titles"
                      className="h-10 border-white/10 bg-white/5 pl-9 text-sm"
                    />
                  </div>
                </form>
                {LINKS.map((link) => {
                  const Icon = link.icon;
                  const active = link.match(route);
                  return (
                    <button
                      key={link.href}
                      type="button"
                      onClick={() => {
                        navigate(link.href);
                        setOpen(false);
                      }}
                      className={cn(
                        'flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition',
                        active ? 'bg-rose-500/15 text-rose-300' : 'text-zinc-300 hover:bg-white/5',
                      )}
                    >
                      <Icon className="h-4.5 w-4.5" aria-hidden />
                      {link.label}
                    </button>
                  );
                })}
                <div className="my-2 h-px bg-white/10" />
                {mobileExtraLinks.map((link) => {
                  const Icon = link.icon;
                  const active = link.match(route);
                  return (
                    <button
                      key={link.href}
                      type="button"
                      onClick={() => {
                        navigate(link.href);
                        setOpen(false);
                      }}
                      className={cn(
                        'flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition',
                        active ? 'bg-rose-500/15 text-rose-300' : 'text-zinc-300 hover:bg-white/5',
                      )}
                    >
                      <Icon className="h-4.5 w-4.5" aria-hidden />
                      {link.label}
                    </button>
                  );
                })}
                <div className="my-2 h-px bg-white/10" />
                <button
                  type="button"
                  onClick={() => {
                    navigate('/admin');
                    setOpen(false);
                  }}
                  className={cn(
                    'flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition',
                    route?.view === 'admin' ? 'bg-rose-500/15 text-rose-300' : 'text-zinc-300 hover:bg-white/5',
                  )}
                >
                  <ShieldCheck className="h-4.5 w-4.5" aria-hidden />
                  Admin panel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    navigate('/category/mined');
                    setOpen(false);
                  }}
                  className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium text-zinc-300 transition hover:bg-white/5"
                >
                  <MonitorPlay className="h-4.5 w-4.5" aria-hidden />
                  Mined content
                </button>
                {user ? (
                  <button
                    type="button"
                    onClick={async () => {
                      setOpen(false);
                      await handleLogout();
                    }}
                    className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium text-rose-400 transition hover:bg-rose-500/10"
                  >
                    <LogOut className="h-4.5 w-4.5" aria-hidden />
                    Sign out ({user.username})
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      navigate('/auth');
                      setOpen(false);
                    }}
                    className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-bold text-white transition hover:bg-rose-500/15"
                  >
                    <LogIn className="h-4.5 w-4.5 text-rose-400" aria-hidden />
                    Sign in / Create account
                  </button>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  );
}
