'use client';

/**
 * ai-view.tsx — AI hub (#/ai). Provider status header + four tools:
 * Recommendations (aiRecommendations), Summarize (aiSummarize with a library
 * content picker), Describe (aiDescribe form) and Chat (auth-gated
 * content-scoped aiChat). Plan-quota (402) errors render upgrade cards.
 */

import { useEffect, useRef, useState } from 'react';
import { Crown, Dices, Loader2, Search, Send, Sparkles, X, Zap } from 'lucide-react';
import { toast } from 'sonner';
import { platform, PlatformError, type AiRecommendation, type PlatformUser } from '@/lib/animaxia/platform';
import { useApi } from '@/lib/animaxia/hooks';
import { navigate, type AppRoute } from '@/lib/animaxia/router';
import { useAuth } from '@/components/animaxia/auth-provider';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { Container, PageHeader } from '../section';
import { BrandPlaceholder, EmptyState, ErrorState, LoadingCards, TypeBadge } from '../states';

type AiTab = 'recommendations' | 'summarize' | 'describe' | 'chat';

const TAB_TRIGGER_CLASS =
  'rounded-lg px-3 text-zinc-400 hover:text-zinc-100 data-[state=active]:bg-rose-600 data-[state=active]:text-white sm:px-4';

/* ------------------------------- local helpers ------------------------------ */

interface Suggestion {
  id: number;
  title: string;
  type: string;
  thumbnail: string | null;
}

interface ChatMessage {
  role: 'user' | 'ai';
  text: string;
}

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  } catch {
    toast.error('Clipboard is not available in this browser');
  }
}

/** Renders AI output: bullet lines ("- " / "• ") become styled list items. */
function AiText({ text }: { text: string }) {
  const lines = text
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);
  return (
    <div className="space-y-2.5">
      {lines.map((line, i) => {
        if (line.startsWith('- ') || line.startsWith('• ')) {
          return (
            <div key={i} className="flex gap-2.5">
              <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full bg-rose-400" aria-hidden />
              <p className="text-sm leading-relaxed text-zinc-300">{line.slice(2)}</p>
            </div>
          );
        }
        return (
          <p key={i} className="text-sm leading-relaxed text-zinc-300">
            {line}
          </p>
        );
      })}
    </div>
  );
}

function ProviderBadge({ provider }: { provider: string }) {
  const isLlm = provider === 'z-ai';
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider',
        isLlm ? 'border-rose-500/30 bg-rose-500/10 text-rose-300' : 'border-amber-500/30 bg-amber-500/10 text-amber-300',
      )}
    >
      {isLlm ? <Sparkles className="h-3 w-3" aria-hidden /> : <Zap className="h-3 w-3" aria-hidden />}
      {provider}
    </span>
  );
}

function UpgradeCard({ message }: { message: string }) {
  return (
    <div className="rounded-2xl border border-amber-500/30 bg-amber-500/[0.07] p-6 text-center">
      <p className="flex items-center justify-center gap-2 font-semibold text-amber-300">
        <Crown className="h-5 w-5 shrink-0" aria-hidden />
        Daily AI limit reached
      </p>
      <p className="mx-auto mt-1 max-w-md text-sm leading-relaxed text-zinc-400">{message}</p>
      <Button
        type="button"
        className="mt-4 bg-rose-600 font-bold text-white hover:bg-rose-500"
        onClick={() => navigate('/premium')}
      >
        <Crown aria-hidden /> See premium plans
      </Button>
    </div>
  );
}

function TypingDots() {
  return (
    <span className="inline-flex items-center gap-1 py-1" role="status" aria-label="AI is thinking">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="h-1.5 w-1.5 animate-bounce rounded-full bg-rose-300"
          style={{ animationDelay: `${i * 150}ms` }}
        />
      ))}
    </span>
  );
}

/* ------------------------------ content picker ------------------------------ */

/**
 * Library content picker: debounced (300 ms) autocomplete dropdown with
 * thumbnails, keyboard (Escape) and click-outside dismissal, and a selected
 * chip. Reused by the Summarize and Chat tabs.
 */
function ContentPicker({
  selected,
  onSelect,
  label,
  inputId,
}: {
  selected: Suggestion | null;
  onSelect: (s: Suggestion | null) => void;
  label: string;
  inputId: string;
}) {
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [loading, setLoading] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  /* Debounced autocomplete (300 ms while typing; instant clear otherwise —
     state updates happen inside the async timer to avoid sync setState). */
  useEffect(() => {
    const q = query.trim();
    const timer = setTimeout(
      () => {
        if (!open || q.length === 0) {
          setSuggestions([]);
          return;
        }
        setLoading(true);
        platform
          .autocomplete(q)
          .then((res) => setSuggestions(res.suggestions))
          .catch(() => setSuggestions([]))
          .finally(() => setLoading(false));
      },
      open && q.length > 0 ? 300 : 0,
    );
    return () => clearTimeout(timer);
  }, [query, open]);

  /* Click-outside closes the dropdown. */
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [open]);

  return (
    <div className="space-y-2" ref={rootRef}>
      <label htmlFor={inputId} className="text-sm font-semibold text-zinc-300">
        {label}
      </label>
      <div className="relative">
        <Search
          className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500"
          aria-hidden
        />
        <Input
          id={inputId}
          type="text"
          role="combobox"
          aria-expanded={open}
          aria-controls={`${inputId}-listbox`}
          aria-autocomplete="list"
          autoComplete="off"
          value={query}
          placeholder="Search the library…"
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={(e) => {
            if (e.key === 'Escape') setOpen(false);
          }}
          className="h-11 rounded-xl border-white/10 bg-white/[0.04] pl-10 text-sm text-zinc-100 placeholder:text-zinc-500 focus-visible:border-rose-500/50 focus-visible:ring-rose-500/30"
        />
        {open && query.trim().length > 0 && (
          <div
            id={`${inputId}-listbox`}
            role="listbox"
            aria-label="Library suggestions"
            className="absolute z-30 mt-2 max-h-72 w-full overflow-y-auto rounded-xl border border-white/10 bg-[#12121c] p-2 shadow-2xl shadow-black/70 custom-scrollbar"
          >
            {loading ? (
              <p className="px-2 py-3 text-xs text-zinc-500">Searching the library…</p>
            ) : suggestions.length === 0 ? (
              <p className="px-2 py-3 text-xs text-zinc-500">No titles match that search.</p>
            ) : (
              suggestions.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  role="option"
                  aria-selected={selected?.id === s.id}
                  onClick={() => {
                    onSelect(s);
                    setQuery('');
                    setOpen(false);
                  }}
                  className="flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-white/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/60"
                >
                  <span className="h-12 w-9 shrink-0 overflow-hidden rounded-md border border-white/10 bg-white/[0.03]">
                    {s.thumbnail ? (
                      <img src={s.thumbnail} alt="" loading="lazy" className="h-full w-full object-cover" />
                    ) : (
                      <BrandPlaceholder title={s.title} />
                    )}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-semibold text-zinc-100">{s.title}</span>
                  </span>
                  <TypeBadge type={s.type} />
                </button>
              ))
            )}
          </div>
        )}
      </div>
      {selected && (
        <div className="flex items-center gap-2">
          <span className="inline-flex max-w-full items-center gap-2 rounded-full border border-rose-500/30 bg-rose-500/10 py-1 pl-1 pr-2 text-sm text-rose-200">
            <span className="h-7 w-7 shrink-0 overflow-hidden rounded-full border border-white/10 bg-white/[0.03]">
              {selected.thumbnail ? (
                <img src={selected.thumbnail} alt="" className="h-full w-full object-cover" />
              ) : (
                <BrandPlaceholder title={selected.title} />
              )}
            </span>
            <span className="truncate font-medium">{selected.title}</span>
            <button
              type="button"
              onClick={() => onSelect(null)}
              aria-label={`Clear ${selected.title}`}
              className="rounded-full p-1 text-rose-300/70 transition hover:bg-rose-500/20 hover:text-rose-100"
            >
              <X className="h-3.5 w-3.5" aria-hidden />
            </button>
          </span>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------- view ---------------------------------- */

export function AiView(_route: { route: AppRoute }) {
  const { user } = useAuth();
  const [tab, setTab] = useState<AiTab>('recommendations');

  const status = useApi('ai-status', () => platform.aiStatus());
  const statusData = status.data;

  return (
    <Container className="space-y-8 py-8 sm:py-10">
      <PageHeader title="AI hub" subtitle="Powered by Animaxia Intelligence">
        <div className="flex flex-wrap items-center gap-2 pt-1">
          {statusData ? (
            statusData.provider === 'z-ai' && statusData.available ? (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-rose-500/30 bg-rose-500/10 px-3 py-1 text-xs font-semibold text-rose-300">
                <Sparkles className="h-3.5 w-3.5" aria-hidden /> LLM online
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-500/30 bg-amber-500/10 px-3 py-1 text-xs font-semibold text-amber-300">
                <Zap className="h-3.5 w-3.5" aria-hidden /> {statusData.provider || 'offline'} mode
              </span>
            )
          ) : (
            <Skeleton className="h-7 w-28 rounded-full" />
          )}
          {statusData && (
            <span className="inline-flex items-center rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-medium text-zinc-400">
              {statusData.requestsToday} requests today
            </span>
          )}
          {statusData &&
            (['free', 'plus', 'pro'] as const)
              .filter((plan) => statusData.quota?.[plan] != null)
              .map((plan) => (
                <span
                  key={plan}
                  className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-medium text-zinc-400"
                >
                  <Crown className="h-3 w-3 text-amber-300/80" aria-hidden />
                  {plan} · {statusData.quota[plan]}/day
                </span>
              ))}
        </div>
      </PageHeader>

      <Tabs value={tab} onValueChange={(v) => setTab(v as AiTab)}>
        <TabsList className="h-10 w-full justify-start gap-1 rounded-xl border border-white/10 bg-white/[0.03] p-1 sm:w-auto">
          <TabsTrigger value="recommendations" className={TAB_TRIGGER_CLASS}>
            Recommendations
          </TabsTrigger>
          <TabsTrigger value="summarize" className={TAB_TRIGGER_CLASS}>
            Summarize
          </TabsTrigger>
          <TabsTrigger value="describe" className={TAB_TRIGGER_CLASS}>
            Describe
          </TabsTrigger>
          <TabsTrigger value="chat" className={TAB_TRIGGER_CLASS}>
            Chat
          </TabsTrigger>
        </TabsList>

        <TabsContent value="recommendations" className="pt-6">
          <RecommendationsTab user={user} />
        </TabsContent>
        <TabsContent value="summarize" className="pt-6">
          <SummarizeTab user={user} />
        </TabsContent>
        <TabsContent value="describe" className="pt-6">
          <DescribeTab />
        </TabsContent>
        <TabsContent value="chat" className="pt-6">
          <ChatTab user={user} />
        </TabsContent>
      </Tabs>
    </Container>
  );
}

/* ---------------------------- recommendations tab ---------------------------- */

function RecommendationsTab({ user }: { user: PlatformUser | null }) {
  const [picks, setPicks] = useState<AiRecommendation[] | null>(null);
  const [provider, setProvider] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [upgrade, setUpgrade] = useState<string | null>(null);

  async function fetchPicks() {
    if (loading) return;
    setLoading(true);
    setError(null);
    setUpgrade(null);
    try {
      const res = await platform.aiRecommendations(8);
      setPicks(res.data);
      setProvider(res.provider);
    } catch (e) {
      if (e instanceof PlatformError && e.upgrade) setUpgrade(e.message);
      else setError(e instanceof Error ? e.message : 'Could not get AI picks');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="rounded-2xl bg-gradient-to-br from-rose-500/50 via-fuchsia-500/30 to-amber-500/40 p-[1px]">
        <div className="rounded-2xl bg-[#0d0d14] p-5 sm:p-7">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="flex items-center gap-2.5 text-xl font-black tracking-tight text-white sm:text-2xl">
                <Dices className="h-6 w-6 text-rose-400" aria-hidden />
                AI picks for you
              </h2>
              <p className="mt-1 max-w-xl text-sm text-zinc-400">
                {user
                  ? 'Eight picks ranked by the Animaxia LLM against your taste profile and watch history.'
                  : 'Eight LLM-ranked picks from the library. Sign in for picks personalized to your taste profile.'}
              </p>
            </div>
            <Button
              type="button"
              size="lg"
              onClick={fetchPicks}
              disabled={loading}
              className="bg-rose-600 font-bold text-white hover:bg-rose-500"
            >
              {loading ? <Loader2 className="animate-spin" aria-hidden /> : <Dices aria-hidden />}
              {loading ? 'Thinking…' : picks ? 'Regenerate' : 'Get AI picks'}
            </Button>
          </div>
        </div>
      </div>

      {upgrade && <UpgradeCard message={upgrade} />}
      {error && !upgrade && <ErrorState message={error} onRetry={fetchPicks} />}
      {loading && <LoadingCards count={8} />}

      {!loading && picks && picks.length === 0 && (
        <EmptyState
          title="No picks right now"
          message="The library is too sparse for the LLM to work with — add a few more titles and try again."
        />
      )}

      {!loading && picks && picks.length > 0 && (
        <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {picks.map((rec) => (
              <RecommendationCard key={rec.content.id} rec={rec} />
            ))}
          </div>
          <p className="flex flex-wrap items-center gap-2 text-xs text-zinc-500">
            Picks generated by Animaxia Intelligence <ProviderBadge provider={provider} />
          </p>
        </>
      )}
    </div>
  );
}

function RecommendationCard({ rec }: { rec: AiRecommendation }) {
  const [imgError, setImgError] = useState(false);
  const c = rec.content;
  const md = c.metadata || {};
  const poster = c.thumbnail || (typeof md.backdrop === 'string' ? md.backdrop : null);
  const showImage = Boolean(poster) && !imgError;

  return (
    <div className="flex flex-col gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3">
      <div className="aspect-[2/3] w-full overflow-hidden rounded-lg border border-white/10 bg-white/[0.03]">
        {showImage ? (
          <img
            src={poster as string}
            alt={`${c.title} poster`}
            loading="lazy"
            onError={() => setImgError(true)}
            className="h-full w-full object-cover"
          />
        ) : (
          <BrandPlaceholder title={c.title} />
        )}
      </div>
      <p className="line-clamp-4 text-sm italic leading-relaxed text-zinc-300">
        <span className="font-bold text-rose-400">&ldquo;</span>
        {rec.reason}
        <span className="font-bold text-rose-400">&rdquo;</span>
      </p>
      <div className="mt-auto space-y-2.5">
        <p className="line-clamp-1 text-sm font-semibold text-zinc-100">{c.title}</p>
        <div className="flex items-center justify-between gap-2">
          <TypeBadge type={c.type} />
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() => navigate(`/content/${c.id}`)}
            className="h-9 border-white/15 bg-white/5 font-semibold hover:bg-white/10"
          >
            View
          </Button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------- summarize tab ------------------------------- */

function SummarizeTab({ user }: { user: PlatformUser | null }) {
  const [selected, setSelected] = useState<Suggestion | null>(null);
  const [result, setResult] = useState<{ summary: string; provider: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [upgrade, setUpgrade] = useState<string | null>(null);

  async function summarize() {
    if (!selected || loading) return;
    setLoading(true);
    setError(null);
    setUpgrade(null);
    try {
      const res = await platform.aiSummarize(selected.id);
      setResult({ summary: res.summary, provider: res.provider });
    } catch (e) {
      if (e instanceof PlatformError && e.upgrade) setUpgrade(e.message);
      else setError(e instanceof Error ? e.message : 'Could not generate a summary');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <Card className="border-white/10 bg-white/[0.03]">
        <CardContent className="space-y-4 p-5 sm:p-6">
          <ContentPicker
            selected={selected}
            onSelect={(s) => {
              setSelected(s);
              setResult(null);
            }}
            label="Pick a title from your library"
            inputId="summarize-picker"
          />
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-xs text-zinc-500">
              {!user && 'Anonymous visitors get 5 AI requests per day — sign in for higher daily limits.'}
            </p>
            <Button
              type="button"
              onClick={summarize}
              disabled={!selected || loading}
              className="bg-rose-600 font-bold text-white hover:bg-rose-500"
            >
              {loading ? <Loader2 className="animate-spin" aria-hidden /> : <Sparkles aria-hidden />}
              {loading ? 'Summarizing…' : 'Summarize'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {upgrade && <UpgradeCard message={upgrade} />}
      {error && !upgrade && <ErrorState message={error} onRetry={summarize} />}

      {loading && (
        <Card className="border-white/10 bg-white/[0.03]" aria-busy="true">
          <CardContent className="space-y-2.5 p-5 sm:p-6">
            <Skeleton className="h-5 w-2/5" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-11/12" />
            <Skeleton className="h-4 w-4/5" />
          </CardContent>
        </Card>
      )}

      {!loading && result && (
        <Card className="border-white/10 bg-white/[0.03]">
          <CardContent className="space-y-4 p-5 sm:p-6">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-bold text-zinc-100">{selected?.title}</h3>
              <ProviderBadge provider={result.provider} />
            </div>
            <AiText text={result.summary} />
            <div className="flex justify-end border-t border-white/5 pt-3">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => void copyText(result.summary)}
                className="border-white/15 bg-white/5 font-semibold hover:bg-white/10"
              >
                Copy summary
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

/* -------------------------------- describe tab -------------------------------- */

const DESCRIBE_TYPES = ['movie', 'tv', 'anime', 'sports', 'news'] as const;

const DESCRIBE_EXAMPLES: { label: string; title: string; type: (typeof DESCRIBE_TYPES)[number]; genres: string }[] = [
  { label: 'Neon cyberpunk revenge saga', title: 'Neon Requiem', type: 'movie', genres: 'Sci-Fi, Action, Thriller' },
  { label: 'Cozy slice-of-life bakery anime', title: 'Flour & Feelings', type: 'anime', genres: 'Slice of Life, Comedy, Gourmet' },
];

function DescribeTab() {
  const [title, setTitle] = useState('');
  const [type, setType] = useState<(typeof DESCRIBE_TYPES)[number]>('movie');
  const [genres, setGenres] = useState('');
  const [result, setResult] = useState<{ description: string; provider: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [upgrade, setUpgrade] = useState<string | null>(null);

  async function describe() {
    const trimmed = title.trim();
    if (!trimmed || loading) return;
    setLoading(true);
    setError(null);
    setUpgrade(null);
    try {
      const genreList = genres
        .split(',')
        .map((g) => g.trim())
        .filter(Boolean);
      const res = await platform.aiDescribe({ title: trimmed, type, genres: genreList.length ? genreList : undefined });
      setResult({ description: res.description, provider: res.provider });
    } catch (e) {
      if (e instanceof PlatformError && e.upgrade) setUpgrade(e.message);
      else setError(e instanceof Error ? e.message : 'Could not generate a description');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <Card className="border-white/10 bg-white/[0.03]">
        <CardContent className="space-y-4 p-5 sm:p-6">
          <div className="space-y-2">
            <label htmlFor="describe-title" className="text-sm font-semibold text-zinc-300">
              Title
            </label>
            <Input
              id="describe-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Neon Requiem"
              maxLength={200}
              className="h-11 rounded-xl border-white/10 bg-white/[0.04] text-sm text-zinc-100 placeholder:text-zinc-500 focus-visible:border-rose-500/50 focus-visible:ring-rose-500/30"
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <label htmlFor="describe-type" className="text-sm font-semibold text-zinc-300">
                Type
              </label>
              <Select value={type} onValueChange={(v) => setType(v as (typeof DESCRIBE_TYPES)[number])}>
                <SelectTrigger
                  id="describe-type"
                  className="h-11 w-full rounded-xl border-white/10 bg-white/[0.04] text-sm text-zinc-100 focus-visible:ring-rose-500/30"
                >
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#12121c] text-zinc-100">
                  {DESCRIBE_TYPES.map((t) => (
                    <SelectItem key={t} value={t} className="capitalize focus:bg-white/10 focus:text-white">
                      <span className="capitalize">{t}</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label htmlFor="describe-genres" className="text-sm font-semibold text-zinc-300">
                Genres <span className="font-normal text-zinc-500">(comma separated)</span>
              </label>
              <Input
                id="describe-genres"
                value={genres}
                onChange={(e) => setGenres(e.target.value)}
                placeholder="e.g. Sci-Fi, Action, Thriller"
                maxLength={200}
                className="h-11 rounded-xl border-white/10 bg-white/[0.04] text-sm text-zinc-100 placeholder:text-zinc-500 focus-visible:border-rose-500/50 focus-visible:ring-rose-500/30"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-zinc-500">Try</span>
            {DESCRIBE_EXAMPLES.map((ex) => (
              <button
                key={ex.label}
                type="button"
                onClick={() => {
                  setTitle(ex.title);
                  setType(ex.type);
                  setGenres(ex.genres);
                }}
                className="rounded-full border border-rose-500/25 bg-rose-500/10 px-3 py-1 text-xs font-medium text-rose-300 transition hover:bg-rose-500/20 hover:text-rose-200"
              >
                {ex.label}
              </button>
            ))}
          </div>

          <div className="flex justify-end">
            <Button
              type="button"
              onClick={describe}
              disabled={!title.trim() || loading}
              className="bg-rose-600 font-bold text-white hover:bg-rose-500"
            >
              {loading ? <Loader2 className="animate-spin" aria-hidden /> : <Sparkles aria-hidden />}
              {loading ? 'Writing…' : 'Generate description'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {upgrade && <UpgradeCard message={upgrade} />}
      {error && !upgrade && <ErrorState message={error} onRetry={describe} />}

      {loading && (
        <Card className="border-white/10 bg-white/[0.03]" aria-busy="true">
          <CardContent className="space-y-2.5 p-5 sm:p-6">
            <Skeleton className="h-5 w-2/5" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-11/12" />
          </CardContent>
        </Card>
      )}

      {!loading && result && (
        <Card className="border-white/10 bg-white/[0.03]">
          <CardContent className="space-y-4 p-5 sm:p-6">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-bold text-zinc-100">{title.trim()}</h3>
              <ProviderBadge provider={result.provider} />
            </div>
            <AiText text={result.description} />
            <div className="flex justify-end border-t border-white/5 pt-3">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => void copyText(result.description)}
                className="border-white/15 bg-white/5 font-semibold hover:bg-white/10"
              >
                Copy description
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

/* ---------------------------------- chat tab ---------------------------------- */

function ChatTab({ user }: { user: PlatformUser | null }) {
  const [selected, setSelected] = useState<Suggestion | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [quotaError, setQuotaError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, busy]);

  if (!user) {
    return (
      <div className="mx-auto max-w-3xl">
        <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white/[0.02] p-10 text-center">
          <div className="rounded-full bg-rose-500/10 p-3 text-rose-300">
            <Sparkles className="h-6 w-6" aria-hidden />
          </div>
          <div>
            <p className="font-semibold text-zinc-100">Sign in to chat with Animaxia AI</p>
            <p className="mt-1 max-w-md text-sm text-zinc-400">
              Ask anything about any title in the library — characters, plots, watch order, hidden gems.
            </p>
          </div>
          <Button
            type="button"
            className="bg-rose-600 font-bold text-white hover:bg-rose-500"
            onClick={() => navigate('/auth')}
          >
            Sign in to chat
          </Button>
        </div>
      </div>
    );
  }

  async function send() {
    const text = input.trim();
    if (!text || !selected || busy) return;
    setBusy(true);
    setQuotaError(null);
    setMessages((prev) => [...prev, { role: 'user', text }]);
    setInput('');
    try {
      const res = await platform.aiChat(selected.id, text);
      setMessages((prev) => [...prev, { role: 'ai', text: res.reply }]);
    } catch (e) {
      if (e instanceof PlatformError && e.upgrade) {
        setQuotaError(e.message);
      } else {
        setMessages((prev) => [...prev, { role: 'ai', text: e instanceof Error ? e.message : 'Something went wrong.' }]);
      }
    } finally {
      setBusy(false);
    }
  }

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      void send();
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <Card className="border-white/10 bg-white/[0.03]">
        <CardContent className="p-5 sm:p-6">
          <ContentPicker
            selected={selected}
            onSelect={(s) => {
              setSelected(s);
              setMessages([]);
              setQuotaError(null);
            }}
            label="Pick a title to talk about"
            inputId="chat-picker"
          />
        </CardContent>
      </Card>

      <div
        ref={scrollRef}
        className="custom-scrollbar max-h-96 space-y-3 overflow-y-auto rounded-2xl border border-white/10 bg-black/20 p-4"
        aria-live="polite"
        aria-label="Chat conversation"
      >
        {messages.length === 0 && !busy && !quotaError && (
          <p className="py-8 text-center text-xs leading-relaxed text-zinc-500">
            {selected
              ? `Ask anything about ${selected.title} — the AI knows the title's details and your conversation history.`
              : 'Pick a title above, then ask anything — characters, plot, where to start…'}
          </p>
        )}
        {messages.map((m, i) => (
          <div key={i} className={cn('flex gap-2.5', m.role === 'user' ? 'justify-end' : 'justify-start')}>
            {m.role === 'ai' && (
              <span className="mt-1 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-gradient-to-br from-rose-500/30 to-fuchsia-500/30">
                <Sparkles className="h-3.5 w-3.5 text-rose-300" aria-hidden />
              </span>
            )}
            <div
              className={cn(
                'max-w-[85%] whitespace-pre-wrap break-words px-3.5 py-2 text-sm leading-relaxed',
                m.role === 'user'
                  ? 'rounded-2xl rounded-br-sm bg-rose-600/20 text-rose-50'
                  : 'rounded-2xl rounded-bl-sm bg-white/5 text-zinc-200',
              )}
            >
              {m.text}
            </div>
          </div>
        ))}
        {busy && (
          <div className="flex justify-start">
            <span className="mt-1 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-gradient-to-br from-rose-500/30 to-fuchsia-500/30">
              <Sparkles className="h-3.5 w-3.5 text-rose-300" aria-hidden />
            </span>
            <div className="rounded-2xl rounded-bl-sm bg-white/5 px-3.5 py-2">
              <TypingDots />
            </div>
          </div>
        )}
      </div>

      {quotaError && <UpgradeCard message={quotaError} />}

      <div className="flex items-end gap-2">
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={selected ? `Ask about ${selected.title}…` : 'Pick a title first…'}
          aria-label="Message Animaxia AI"
          rows={2}
          maxLength={1000}
          disabled={!selected}
          className="min-h-11 flex-1 rounded-xl border-white/10 bg-white/[0.04] text-sm text-zinc-100 placeholder:text-zinc-500 focus-visible:border-rose-500/50 focus-visible:ring-rose-500/30 disabled:opacity-50"
        />
        <Button
          type="button"
          onClick={() => void send()}
          disabled={busy || !selected || !input.trim()}
          aria-label="Send message"
          className="h-11 bg-rose-600 font-bold text-white hover:bg-rose-500"
        >
          {busy ? <Loader2 className="animate-spin" aria-hidden /> : <Send aria-hidden />}
        </Button>
      </div>
      <div className="flex items-center justify-between gap-3">
        <p className="text-[11px] text-zinc-600">Enter to send · Shift+Enter for a new line</p>
        {messages.length > 0 && (
          <button
            type="button"
            onClick={() => {
              setMessages([]);
              setQuotaError(null);
            }}
            className="text-[11px] font-semibold text-zinc-500 transition hover:text-zinc-300"
          >
            Clear conversation
          </button>
        )}
      </div>
    </div>
  );
}

export default AiView;
