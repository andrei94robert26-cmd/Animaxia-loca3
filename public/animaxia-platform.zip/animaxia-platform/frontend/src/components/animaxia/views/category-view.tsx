'use client';

/**
 * category-view.tsx — Browse by category. DB-backed categories render a live
 * provider strip plus a paginated library grid; the news category is a live
 * multi-source browser; the sports category is a football + Formula 1 hub.
 */

import { useMemo, useRef, useState } from 'react';
import { Pickaxe } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { api, animeToItem, dbToItem, mediaToItem, newsToItem } from '@/lib/animaxia/api';
import { useApi, type UseApiResult } from '@/lib/animaxia/hooks';
import { navigate, type AppRoute } from '@/lib/animaxia/router';
import type {
  FootballMatch,
  FootballTableEntry,
  F1Race,
  F1Standing,
  NewsItem,
  NormalizedItem,
} from '@/lib/animaxia/types';
import { cn } from '@/lib/utils';
import { ContentGrid } from '../content-grid';
import { ContentRow } from '../content-row';
import { Pagination } from '../pagination';
import { Container, PageHeader, Section } from '../section';
import { EmptyState, ErrorState } from '../states';

/* ------------------------------- constants ------------------------------- */

const CATEGORY_META: Record<string, { title: string; subtitle: string }> = {
  all: { title: 'All titles', subtitle: 'Everything in your Animaxia library — movies, series, anime and more.' },
  movie: { title: 'Movies', subtitle: 'Films in your collection, plus what is trending on TMDB right now.' },
  tv: { title: 'TV Shows', subtitle: 'Series in your collection, plus popular shows from TMDB.' },
  anime: { title: 'Anime', subtitle: 'Your anime collection, plus what is airing this season.' },
  news: { title: 'News', subtitle: 'Latest headlines pulled live from BBC, CNN, NHK and Al Jazeera.' },
  sports: { title: 'Sports', subtitle: 'Football tables and fixtures, plus the Formula 1 season at a glance.' },
  mined: { title: 'Mined content', subtitle: 'Everything the Animaxia Miner extracted from stream URLs.' },
  featured: { title: 'Featured', subtitle: 'Hand-picked highlights from the Animaxia team.' },
};

const NEWS_SOURCES: { value: string; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'bbc', label: 'BBC' },
  { value: 'cnn', label: 'CNN' },
  { value: 'nhk', label: 'NHK' },
  { value: 'aljazeera', label: 'Al Jazeera' },
];

const COMPETITIONS: { code: string; name: string }[] = [
  { code: 'PL', name: 'Premier League' },
  { code: 'BL1', name: 'Bundesliga' },
  { code: 'PD', name: 'La Liga' },
  { code: 'SA', name: 'Serie A' },
  { code: 'FL1', name: 'Ligue 1' },
  { code: 'CL', name: 'Champions League' },
  { code: 'WC', name: 'World Cup' },
];

const MATCH_STATUS: Record<string, { label: string; className: string }> = {
  FINISHED: { label: 'Finished', className: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300' },
  IN_PLAY: { label: 'Live', className: 'border-rose-500/40 bg-rose-500/15 text-rose-300' },
  PAUSED: { label: 'Live', className: 'border-rose-500/40 bg-rose-500/15 text-rose-300' },
  TIMED: { label: 'Scheduled', className: 'border-white/10 bg-white/5 text-zinc-400' },
  SCHEDULED: { label: 'Scheduled', className: 'border-white/10 bg-white/5 text-zinc-400' },
  POSTPONED: { label: 'Postponed', className: 'border-amber-500/30 bg-amber-500/10 text-amber-300' },
  SUSPENDED: { label: 'Suspended', className: 'border-amber-500/30 bg-amber-500/10 text-amber-300' },
  CANCELLED: { label: 'Cancelled', className: 'border-white/10 bg-white/5 text-zinc-400' },
};

function capitalize(raw: string): string {
  return raw ? raw.charAt(0).toUpperCase() + raw.slice(1) : 'Category';
}

/* --------------------------------- view ---------------------------------- */

export function CategoryView({ route }: { route: AppRoute }) {
  const type = route.params[0] || 'all';

  /* Reset pagination whenever the category changes (adjust during render). */
  const [page, setPage] = useState(1);
  const [lastType, setLastType] = useState(type);
  if (lastType !== type) {
    setLastType(type);
    setPage(1);
  }

  const [newsSource, setNewsSource] = useState('all');
  const [sportTab, setSportTab] = useState<'football' | 'f1'>('football');
  const [competition, setCompetition] = useState('PL');

  const isNews = type === 'news';
  const isSports = type === 'sports';
  const isGrid = !isNews && !isSports;
  const hasStrip = type === 'movie' || type === 'tv' || type === 'anime';

  const meta =
    CATEGORY_META[type] ?? {
      title: capitalize(type),
      subtitle: 'Browse every title Animaxia has filed under this category.',
    };

  const listRes = useApi(
    `cat-${type}-${page}`,
    () => api.all({ type: type === 'all' ? undefined : type, page, limit: 24 }),
    { enabled: isGrid },
  );

  const stripRes = useApi(
    `cat-strip-${type}`,
    async (): Promise<NormalizedItem[]> => {
      if (type === 'movie') return (await api.moviesTrending('day')).data.map(mediaToItem);
      if (type === 'tv') return (await api.tvPopular()).data.map(mediaToItem);
      return (await api.animeSeason()).data.map(animeToItem);
    },
    { enabled: hasStrip },
  );

  const newsRes = useApi(`cat-news-${newsSource}`, () => api.news(newsSource, 24), { enabled: isNews });

  const standingsRes = useApi(`fb-standings-${competition}`, () => api.footballStandings(competition), {
    enabled: isSports,
  });
  const matchesRes = useApi(`fb-matches-${competition}`, () => api.footballMatches(competition, 10), {
    enabled: isSports,
  });
  const f1StandingsRes = useApi('f1-standings', () => api.f1Standings(), {
    enabled: isSports && sportTab === 'f1',
  });
  const f1ScheduleRes = useApi('f1-schedule', () => api.f1Schedule(), {
    enabled: isSports && sportTab === 'f1',
  });

  const items = useMemo(() => (listRes.data?.data ?? []).map(dbToItem), [listRes.data]);
  const gridRef = useRef<HTMLDivElement>(null);

  const stripMeta =
    type === 'movie'
      ? { title: 'Trending on TMDB', subtitle: 'Today’s most-watched films worldwide' }
      : type === 'tv'
        ? { title: 'Popular on TMDB', subtitle: 'Series people cannot stop watching' }
        : { title: 'Airing this season', subtitle: 'Currently broadcasting in Japan' };

  const goToPage = (next: number) => {
    setPage(next);
    gridRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <Container className="space-y-8 py-8 sm:py-10">
      <PageHeader title={meta.title} subtitle={meta.subtitle}>
        {isGrid && !listRes.loading && listRes.data && (
          <p className="text-sm font-medium text-zinc-500">
            Showing {listRes.data.data.length} of {listRes.data.total}{' '}
            {listRes.data.total === 1 ? 'title' : 'titles'}
          </p>
        )}
      </PageHeader>

      {isGrid && (
        <>
          {type === 'mined' && (
            <Alert className="border-rose-500/20 bg-rose-500/5">
              <Pickaxe className="h-4 w-4 text-rose-400" aria-hidden />
              <AlertTitle className="text-zinc-100">Extracted by the Animaxia Miner</AlertTitle>
              <AlertDescription className="text-zinc-400">
                <span>
                  Mined titles are extracted by the Animaxia Miner from any URL — open the Admin
                  panel to mine a new stream.
                </span>
                <Button
                  size="sm"
                  onClick={() => navigate('/admin')}
                  className="mt-2 bg-rose-600 font-semibold text-white hover:bg-rose-500"
                >
                  Open Admin panel
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {hasStrip &&
            (stripRes.error && !stripRes.loading && !stripRes.data ? (
              <ErrorState message={stripRes.error} onRetry={stripRes.refetch} compact />
            ) : (
              <ContentRow
                title={stripMeta.title}
                subtitle={stripMeta.subtitle}
                items={stripRes.data ?? []}
                loading={stripRes.loading}
                emptyMessage="Live provider data is unavailable right now."
              />
            ))}

          <div ref={gridRef} className="scroll-mt-24 space-y-6">
            {listRes.error && !listRes.loading && !listRes.data ? (
              <ErrorState message={listRes.error} onRetry={listRes.refetch} />
            ) : (
              <ContentGrid
                items={items}
                loading={listRes.loading}
                skeletonCount={12}
                emptyTitle={type === 'all' ? 'Your library is empty' : `No ${meta.title.toLowerCase()} yet`}
                emptyMessage="Nothing has been added to this category so far — add titles from any detail page."
              />
            )}
            <Pagination page={page} totalPages={listRes.data?.totalPages ?? 1} onPage={goToPage} />
          </div>
        </>
      )}

      {isNews && <NewsPanel source={newsSource} onSource={setNewsSource} res={newsRes} />}

      {isSports && (
        <Tabs defaultValue="football" onValueChange={(value) => setSportTab(value as 'football' | 'f1')}>
          <TabsList className="h-10 w-full justify-start gap-1 rounded-xl border border-white/10 bg-white/[0.03] p-1 sm:w-auto">
            <TabsTrigger
              value="football"
              className="px-4 text-zinc-400 hover:text-zinc-100 data-[state=active]:bg-rose-600 data-[state=active]:text-white data-[state=active]:shadow-rose-900/40 sm:px-5"
            >
              Football
            </TabsTrigger>
            <TabsTrigger
              value="f1"
              className="px-4 text-zinc-400 hover:text-zinc-100 data-[state=active]:bg-rose-600 data-[state=active]:text-white data-[state=active]:shadow-rose-900/40 sm:px-5"
            >
              Formula 1
            </TabsTrigger>
          </TabsList>
          <TabsContent value="football" className="pt-6">
            <FootballPanel
              competition={competition}
              onCompetition={setCompetition}
              standingsRes={standingsRes}
              matchesRes={matchesRes}
            />
          </TabsContent>
          <TabsContent value="f1" className="pt-6">
            <F1Panel standingsRes={f1StandingsRes} scheduleRes={f1ScheduleRes} />
          </TabsContent>
        </Tabs>
      )}
    </Container>
  );
}

/* ------------------------------ news panel ------------------------------- */

function NewsPanel({
  source,
  onSource,
  res,
}: {
  source: string;
  onSource: (value: string) => void;
  res: UseApiResult<{ data: NewsItem[] }>;
}) {
  const items = useMemo(() => (res.data?.data ?? []).map(newsToItem), [res.data]);
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-2" role="group" aria-label="News source filter">
        {NEWS_SOURCES.map((s) => (
          <FilterChip key={s.value} active={source === s.value} onClick={() => onSource(s.value)}>
            {s.label}
          </FilterChip>
        ))}
      </div>
      {res.error && !res.loading && !res.data ? (
        <ErrorState message={res.error} onRetry={res.refetch} />
      ) : (
        <ContentGrid
          items={items}
          loading={res.loading}
          skeletonCount={12}
          emptyTitle="No headlines right now"
          emptyMessage="This feed returned no recent articles — try another source."
        />
      )}
    </div>
  );
}

/* ---------------------------- football panel ----------------------------- */

function FootballPanel({
  competition,
  onCompetition,
  standingsRes,
  matchesRes,
}: {
  competition: string;
  onCompetition: (code: string) => void;
  standingsRes: UseApiResult<{ data: { competition: string; table: FootballTableEntry[] } }>;
  matchesRes: UseApiResult<{ data: FootballMatch[] }>;
}) {
  const competitionName = COMPETITIONS.find((c) => c.code === competition)?.name ?? competition;
  return (
    <div className="space-y-8">
      <div className="space-y-3">
        <h2 className="text-lg font-bold text-zinc-100">Competition</h2>
        <div className="flex flex-wrap gap-2" role="group" aria-label="Competition filter">
          {COMPETITIONS.map((c) => (
            <FilterChip key={c.code} active={competition === c.code} onClick={() => onCompetition(c.code)}>
              {c.name}
            </FilterChip>
          ))}
        </div>
      </div>

      <Section title="Standings" subtitle={`Current ${competitionName} table`}>
        {standingsRes.loading ? (
          <Skeleton className="h-80 w-full rounded-xl" />
        ) : standingsRes.error ? (
          <ErrorState message={standingsRes.error} onRetry={standingsRes.refetch} compact />
        ) : !standingsRes.data || standingsRes.data.data.table.length === 0 ? (
          <EmptyState title="No standings available" message="This competition has no table data right now." />
        ) : (
          <StandingsTable entries={standingsRes.data.data.table} />
        )}
      </Section>

      <Section title="Fixtures & results" subtitle="Upcoming matches and recent scores">
        {matchesRes.loading ? (
          <Skeleton className="h-72 w-full rounded-xl" />
        ) : matchesRes.error ? (
          <ErrorState message={matchesRes.error} onRetry={matchesRes.refetch} compact />
        ) : !matchesRes.data || matchesRes.data.data.length === 0 ? (
          <EmptyState title="No matches scheduled" message="There are no upcoming fixtures for this competition." />
        ) : (
          <div className="overflow-hidden rounded-xl border border-white/10 bg-white/[0.02]">
            <div className="divide-y divide-white/5">
              {matchesRes.data.data.map((match) => (
                <MatchRow key={match.id} match={match} />
              ))}
            </div>
          </div>
        )}
      </Section>
    </div>
  );
}

function StandingsTable({ entries }: { entries: FootballTableEntry[] }) {
  return (
    <div className="custom-scrollbar overflow-x-auto rounded-xl border border-white/10 bg-white/[0.02]">
      <Table className="min-w-[620px]">
        <TableHeader>
          <TableRow className="border-white/10 hover:bg-transparent">
            <TableHead className="w-12 text-center text-xs font-semibold uppercase tracking-wider text-zinc-500">#</TableHead>
            <TableHead className="text-xs font-semibold uppercase tracking-wider text-zinc-500">Team</TableHead>
            <TableHead className="text-center text-xs font-semibold uppercase tracking-wider text-zinc-500">P</TableHead>
            <TableHead className="text-center text-xs font-semibold uppercase tracking-wider text-zinc-500">W</TableHead>
            <TableHead className="text-center text-xs font-semibold uppercase tracking-wider text-zinc-500">D</TableHead>
            <TableHead className="text-center text-xs font-semibold uppercase tracking-wider text-zinc-500">L</TableHead>
            <TableHead className="text-center text-xs font-semibold uppercase tracking-wider text-zinc-500">GD</TableHead>
            <TableHead className="text-center text-xs font-semibold uppercase tracking-wider text-zinc-500">Pts</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {entries.map((entry) => (
            <TableRow key={entry.team} className="border-white/5 hover:bg-white/5">
              <TableCell
                className={cn(
                  'text-center font-bold tabular-nums',
                  entry.rank <= 4 ? 'text-emerald-400' : 'text-zinc-500',
                )}
              >
                {entry.rank}
              </TableCell>
              <TableCell className="font-medium text-zinc-100">
                <span className="flex items-center gap-2.5">
                  {entry.teamCrest ? (
                    <img
                      src={entry.teamCrest}
                      alt=""
                      aria-hidden
                      loading="lazy"
                      className="h-5 w-5 shrink-0 object-contain"
                    />
                  ) : null}
                  <span className="truncate">{entry.team}</span>
                </span>
              </TableCell>
              <TableCell className="text-center tabular-nums text-zinc-300">{entry.played}</TableCell>
              <TableCell className="text-center tabular-nums text-zinc-300">{entry.won}</TableCell>
              <TableCell className="text-center tabular-nums text-zinc-300">{entry.draw}</TableCell>
              <TableCell className="text-center tabular-nums text-zinc-300">{entry.lost}</TableCell>
              <TableCell className="text-center tabular-nums text-zinc-400">
                {entry.goalDifference > 0 ? `+${entry.goalDifference}` : entry.goalDifference}
              </TableCell>
              <TableCell className="text-center font-bold tabular-nums text-white">{entry.points}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function MatchRow({ match }: { match: FootballMatch }) {
  const finished =
    match.status === 'FINISHED' && match.score.home != null && match.score.away != null;
  const date = new Date(match.utcDate);
  const dateLabel = date.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    timeZone: 'UTC',
  });
  const timeLabel = date.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    timeZone: 'UTC',
  });
  return (
    <div className="flex flex-col gap-3 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="grid min-w-0 flex-1 grid-cols-[1fr_auto_1fr] items-center gap-3">
        <div className="flex min-w-0 items-center justify-end gap-2">
          <span className="truncate text-right text-sm font-medium text-zinc-200">{match.home}</span>
          {match.homeCrest ? (
            <img src={match.homeCrest} alt="" aria-hidden loading="lazy" className="h-6 w-6 shrink-0 object-contain" />
          ) : null}
        </div>
        <div className="w-14 text-center text-sm font-bold">
          {finished ? (
            <span className="text-emerald-400">
              {match.score.home} – {match.score.away}
            </span>
          ) : (
            <span className="text-zinc-500">vs</span>
          )}
        </div>
        <div className="flex min-w-0 items-center gap-2">
          {match.awayCrest ? (
            <img src={match.awayCrest} alt="" aria-hidden loading="lazy" className="h-6 w-6 shrink-0 object-contain" />
          ) : null}
          <span className="truncate text-sm font-medium text-zinc-200">{match.away}</span>
        </div>
      </div>
      <div className="flex items-center gap-3 sm:flex-col sm:items-end sm:gap-1">
        <span className="text-xs text-zinc-500">
          {dateLabel} · {timeLabel} UTC
        </span>
        <StatusBadge status={match.status} />
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const meta = MATCH_STATUS[status] ?? { label: status, className: 'border-white/10 bg-white/5 text-zinc-400' };
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider',
        meta.className,
      )}
    >
      {meta.label}
    </span>
  );
}

/* ------------------------------- F1 panel -------------------------------- */

function F1Panel({
  standingsRes,
  scheduleRes,
}: {
  standingsRes: UseApiResult<{ data: F1Standing[] }>;
  scheduleRes: UseApiResult<{ data: F1Race[] }>;
}) {
  return (
    <div className="space-y-8">
      <Section title="Driver standings" subtitle="The current championship battle">
        {standingsRes.loading ? (
          <Skeleton className="h-80 w-full rounded-xl" />
        ) : standingsRes.error ? (
          <ErrorState message={standingsRes.error} onRetry={standingsRes.refetch} compact />
        ) : !standingsRes.data || standingsRes.data.data.length === 0 ? (
          <EmptyState title="No standings yet" message="Driver standings are not available right now." />
        ) : (
          <div className="custom-scrollbar overflow-x-auto rounded-xl border border-white/10 bg-white/[0.02]">
            <Table className="min-w-[480px]">
              <TableHeader>
                <TableRow className="border-white/10 hover:bg-transparent">
                  <TableHead className="w-12 text-center text-xs font-semibold uppercase tracking-wider text-zinc-500">#</TableHead>
                  <TableHead className="text-xs font-semibold uppercase tracking-wider text-zinc-500">Driver</TableHead>
                  <TableHead className="text-xs font-semibold uppercase tracking-wider text-zinc-500">Team</TableHead>
                  <TableHead className="text-center text-xs font-semibold uppercase tracking-wider text-zinc-500">Wins</TableHead>
                  <TableHead className="text-center text-xs font-semibold uppercase tracking-wider text-zinc-500">Pts</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {standingsRes.data.data.map((row) => (
                  <TableRow key={row.driver} className="border-white/5 hover:bg-white/5">
                    <TableCell className="text-center font-bold tabular-nums text-zinc-500">{row.position}</TableCell>
                    <TableCell className="font-medium text-zinc-100">{row.driver}</TableCell>
                    <TableCell className="text-zinc-400">{row.team}</TableCell>
                    <TableCell className="text-center tabular-nums text-zinc-300">{row.wins}</TableCell>
                    <TableCell className="text-center font-bold tabular-nums text-white">{row.points}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Section>

      <Section title="Race calendar" subtitle="Every round of the season">
        {scheduleRes.loading ? (
          <Skeleton className="h-72 w-full rounded-xl" />
        ) : scheduleRes.error ? (
          <ErrorState message={scheduleRes.error} onRetry={scheduleRes.refetch} compact />
        ) : !scheduleRes.data || scheduleRes.data.data.length === 0 ? (
          <EmptyState title="No races scheduled" message="The race calendar is not available yet." />
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {scheduleRes.data.data.map((race) => (
              <RaceCard key={`${race.round}-${race.race}`} race={race} />
            ))}
          </div>
        )}
      </Section>
    </div>
  );
}

function RaceCard({ race }: { race: F1Race }) {
  const date = new Date(race.date);
  const dateLabel = date.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    timeZone: 'UTC',
  });
  return (
    <div className="flex items-center gap-4 rounded-xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-rose-500/30">
      <span
        aria-label={`Round ${race.round}`}
        className="grid h-11 w-11 shrink-0 place-items-center rounded-lg border border-rose-500/30 bg-rose-500/15 text-base font-black text-rose-300"
      >
        {race.round}
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate font-semibold text-zinc-100">{race.race}</p>
        <p className="mt-0.5 truncate text-xs text-zinc-500">
          {[race.circuit, race.locality, race.country].filter(Boolean).join(' — ')}
        </p>
      </div>
      <div className="shrink-0 text-right">
        <p className="text-sm font-medium text-zinc-300">{dateLabel}</p>
        {race.time ? <p className="text-xs text-zinc-500">{race.time.slice(0, 5)} UTC</p> : null}
      </div>
    </div>
  );
}

/* ------------------------------ shared bits ------------------------------ */

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        'rounded-full border px-4 py-2 text-sm font-medium transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/60',
        active
          ? 'border-rose-500/60 bg-rose-500/15 text-rose-300'
          : 'border-white/10 bg-white/[0.04] text-zinc-300 hover:border-white/25 hover:text-white',
      )}
    >
      {children}
    </button>
  );
}
