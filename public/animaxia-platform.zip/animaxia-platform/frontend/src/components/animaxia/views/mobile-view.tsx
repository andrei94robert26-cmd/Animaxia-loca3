'use client';

/**
 * mobile-view.tsx — Animaxia Mobile API showcase: a live phone-shaped preview
 * fed by /api/mobile/home, API documentation cards and a player-payload
 * inspector fed by /api/mobile/player/:id.
 */

import { useState } from 'react';
import {
  BatteryFull,
  Film,
  House,
  Play,
  Search,
  Signal,
  Smartphone,
  Wifi,
  X,
} from 'lucide-react';
import { platform, type MobileItem } from '@/lib/animaxia/platform';
import { useApi } from '@/lib/animaxia/hooks';
import type { AppRoute } from '@/lib/animaxia/router';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { Container, PageHeader } from '../section';
import { EmptyState, ErrorState, RatingBadge, TypeBadge } from '../states';

/* ------------------------------ endpoints ------------------------------ */

const MOBILE_ENDPOINTS: { method: string; path: string; desc: string }[] = [
  { method: 'GET', path: '/api/mobile/home', desc: 'Hero + curated rows for the home screen' },
  { method: 'GET', path: '/api/mobile/player/:id', desc: 'Stream payload for the native player' },
  { method: 'GET', path: '/api/mobile/profile', desc: 'Account, plan and watch stats' },
  { method: 'GET', path: '/api/mobile/config', desc: 'Versions and feature flags' },
];

/* ---------------------------- phone helpers ---------------------------- */

function Thumb({ src, alt, className }: { src: string | null; alt: string; className?: string }) {
  if (src) {
    return (
      <img
        src={src}
        alt={alt}
        loading="lazy"
        className={cn('h-36 w-full rounded-lg border border-white/10 object-cover', className)}
      />
    );
  }
  return (
    <div
      className={cn(
        'grid h-36 w-full place-items-center rounded-lg border border-white/10 bg-gradient-to-br from-rose-600/30 to-fuchsia-600/20',
        className,
      )}
    >
      <Film className="h-6 w-6 text-rose-300/60" aria-hidden />
    </div>
  );
}

function PhoneMockup({
  hero,
  rows,
  selectedId,
  onSelect,
}: {
  hero: MobileItem | null;
  rows: { key: string; title: string; items: MobileItem[] }[];
  selectedId: number | null;
  onSelect: (item: MobileItem) => void;
}) {
  return (
    <div
      className="relative mx-auto flex h-[620px] w-[300px] flex-col overflow-hidden rounded-[2.8rem] border-[10px] border-zinc-800 bg-[#0a0a10] shadow-2xl shadow-black/60 sm:w-[340px]"
      aria-label="Animaxia mobile app preview"
    >
      {/* Notch */}
      <div className="absolute left-1/2 top-2 z-20 h-5 w-24 -translate-x-1/2 rounded-full bg-zinc-800" aria-hidden />

      {/* Status bar */}
      <div className="flex items-center justify-between px-5 pb-1 pt-3 text-[10px] font-medium text-zinc-400">
        <span>9:41</span>
        <span className="flex items-center gap-1.5">
          <Signal className="h-3.5 w-3.5" aria-hidden />
          <Wifi className="h-3.5 w-3.5" aria-hidden />
          <BatteryFull className="h-3.5 w-3.5" aria-hidden />
        </span>
      </div>

      {/* Scrollable app content */}
      <div className="no-scrollbar flex-1 space-y-5 overflow-y-auto p-3 pb-4">
        {/* Hero */}
        {hero ? (
          <div className="relative h-44 shrink-0 overflow-hidden rounded-2xl border border-white/10">
            {hero.backdrop ? (
              <img src={hero.backdrop} alt="" className="h-full w-full object-cover" />
            ) : (
              <div className="h-full w-full bg-gradient-to-br from-rose-600/40 to-fuchsia-600/30" />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 space-y-1.5 p-3">
              <h3 className="line-clamp-2 text-lg font-black leading-tight text-white">{hero.title}</h3>
              <div className="flex items-center gap-2">
                <TypeBadge type={hero.type} />
                <RatingBadge value={hero.rating} />
              </div>
            </div>
          </div>
        ) : (
          <div className="h-44 shrink-0 rounded-2xl bg-gradient-to-br from-rose-600/40 to-fuchsia-600/30" />
        )}

        {/* Rows */}
        {rows.map((row) => (
          <div key={row.key} className="space-y-2">
            <div className="flex items-center justify-between px-1">
              <p className="text-xs font-bold uppercase tracking-wide text-zinc-400">{row.title}</p>
              <span className="text-[10px] font-semibold text-rose-400">See all</span>
            </div>
            <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
              {row.items.map((item) => (
                <button
                  key={`${row.key}-${item.id}`}
                  type="button"
                  onClick={() => onSelect(item)}
                  aria-label={`Open ${item.title}`}
                  className="w-24 shrink-0 rounded-lg text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/60"
                >
                  <Thumb
                    src={item.thumbnail}
                    alt={item.title}
                    className={cn(selectedId === item.id && 'ring-2 ring-rose-500')}
                  />
                  <p className="mt-1 line-clamp-2 text-[10px] font-medium leading-tight text-zinc-300">
                    {item.title}
                  </p>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Bottom tab bar (decorative) */}
      <div
        className="flex items-end justify-around border-t border-white/10 bg-[#0a0a10] px-2 py-2 text-zinc-500"
        aria-hidden
      >
        <House className="h-5 w-5" />
        <Search className="h-5 w-5" />
        <span className="-mt-6 grid h-12 w-12 place-items-center rounded-full bg-rose-600 text-white shadow-lg shadow-rose-900/50">
          <Play className="h-5 w-5 fill-white" />
        </span>
        <Film className="h-5 w-5" />
        <span className="grid h-5 w-5 place-items-center rounded-full bg-gradient-to-br from-rose-500/40 to-fuchsia-500/30 text-[8px] font-bold text-rose-200">
          A
        </span>
      </div>
    </div>
  );
}

/* --------------------------- player payload ---------------------------- */

function modeClass(mode: string): string {
  if (mode === 'direct') return 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300';
  if (mode === 'trailer') return 'border-amber-500/30 bg-amber-500/10 text-amber-300';
  return 'border-white/10 bg-white/5 text-zinc-400';
}

function PlayerPayloadCard({ item, onClose }: { item: MobileItem; onClose: () => void }) {
  const player = useApi(`mobile-player-${item.id}`, () => platform.mobilePlayer(item.id));

  return (
    <Card className="border-rose-500/20 bg-white/[0.03]">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2">
            <CardTitle className="truncate text-base">Player payload</CardTitle>
            <span
              className={cn(
                'shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider',
                player.data ? modeClass(player.data.mode) : 'border-white/10 bg-white/5 text-zinc-400',
              )}
            >
              {player.data?.mode ?? '…'}
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Close player payload"
            className="h-7 w-7 shrink-0 text-zinc-500 hover:bg-white/10 hover:text-zinc-200"
            onClick={onClose}
          >
            <X className="h-4 w-4" aria-hidden />
          </Button>
        </div>
        <CardDescription className="truncate">
          GET /api/mobile/player/{item.id} — {item.title}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {player.loading && !player.data ? (
          <div className="space-y-2">
            <Skeleton className="h-5 w-2/3" />
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        ) : player.error ? (
          <ErrorState message={player.error} onRetry={player.refetch} compact />
        ) : player.data ? (
          <>
            <div className="flex flex-wrap items-center gap-2">
              <TypeBadge type={player.data.content.type} />
              <RatingBadge value={player.data.content.rating} />
              {player.data.allowedTypes.map((t) => (
                <span
                  key={t}
                  className="rounded-full border border-white/10 bg-white/[0.04] px-2 py-0.5 font-mono text-[10px] text-zinc-400"
                >
                  {t}
                </span>
              ))}
            </div>

            <div className="space-y-1.5">
              <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                Sources ({player.data.sources.length})
              </p>
              {player.data.sources.length === 0 ? (
                <p className="text-sm text-zinc-500">No sources attached to this title.</p>
              ) : (
                player.data.sources.map((s, i) => (
                  <div
                    key={`${s.type}-${i}-${s.url}`}
                    className="flex items-center gap-2 rounded-lg border border-white/5 bg-white/[0.02] px-2.5 py-1.5"
                  >
                    <span className="shrink-0 rounded border border-rose-500/30 bg-rose-500/10 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-rose-300">
                      {s.type}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-xs text-zinc-300">
                      {s.label || s.url}
                    </span>
                  </div>
                ))
              )}
            </div>

            {player.data.primary && (
              <div className="space-y-1.5">
                <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Primary URL</p>
                <pre className="custom-scrollbar overflow-x-auto rounded-lg border border-white/10 bg-black/50 p-2.5 font-mono text-[11px] text-zinc-300">
                  {player.data.primary.url}
                </pre>
              </div>
            )}

            {player.data.nextUp && (
              <p className="text-xs text-zinc-500">
                Next up: <span className="font-semibold text-zinc-300">{player.data.nextUp.title}</span>
              </p>
            )}
          </>
        ) : null}
      </CardContent>
    </Card>
  );
}

/* -------------------------------- view --------------------------------- */

export function MobileView(_props: { route: AppRoute }) {
  const [selected, setSelected] = useState<MobileItem | null>(null);

  const home = useApi('mobile:home', () => platform.mobileHome());
  const config = useApi('mobile:config', () => platform.mobileConfig());

  return (
    <Container className="space-y-8 py-8 sm:py-10">
      <PageHeader
        title="Animaxia Mobile"
        subtitle="The complete mobile API, live in a phone-shaped preview — tap any tile to inspect its player payload."
      />

      <div className="grid items-start gap-10 lg:grid-cols-[minmax(0,400px)_minmax(0,1fr)]">
        {/* LEFT — phone */}
        <div>
          {home.loading && !home.data ? (
            <div
              className="mx-auto flex h-[620px] w-[300px] flex-col gap-4 rounded-[2.8rem] border-[10px] border-zinc-800 bg-[#0a0a10] p-4 sm:w-[340px]"
              aria-busy="true"
              aria-label="Loading mobile home"
            >
              <Skeleton className="h-5 w-24 self-center rounded-full" />
              <Skeleton className="h-44 w-full rounded-2xl" />
              {Array.from({ length: 2 }).map((_, i) => (
                <div key={i} className="space-y-2">
                  <Skeleton className="h-3 w-28" />
                  <div className="flex gap-2">
                    {Array.from({ length: 4 }).map((_, j) => (
                      <Skeleton key={j} className="h-36 w-24 shrink-0 rounded-lg" />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : home.error && !home.data ? (
            <ErrorState message={home.error} onRetry={home.refetch} />
          ) : home.data ? (
            <PhoneMockup
              hero={home.data.hero}
              rows={home.data.rows}
              selectedId={selected?.id ?? null}
              onSelect={setSelected}
            />
          ) : null}
        </div>

        {/* RIGHT — API docs */}
        <div className="space-y-4">
          {selected && <PlayerPayloadCard item={selected} onClose={() => setSelected(null)} />}

          {/* Endpoints */}
          <Card className="border-white/10 bg-white/[0.03]">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Smartphone className="h-4 w-4 text-rose-400" aria-hidden />
                Mobile API
              </CardTitle>
              <CardDescription>
                Four endpoints power the native app — same backend, trimmed payloads.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="custom-scrollbar overflow-x-auto rounded-xl border border-white/10 bg-black/40">
                <div className="min-w-[440px] divide-y divide-white/5">
                  {MOBILE_ENDPOINTS.map((e) => (
                    <div key={e.path} className="flex flex-wrap items-center gap-x-3 gap-y-1 px-4 py-2.5">
                      <span className="inline-flex w-[52px] shrink-0 justify-center rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
                        {e.method}
                      </span>
                      <span className="font-mono text-xs text-zinc-200">{e.path}</span>
                      <span className="w-full text-[11px] text-zinc-500 sm:w-auto sm:flex-1 sm:text-right">
                        {e.desc}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Config */}
          <Card className="border-white/10 bg-white/[0.03]">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">App configuration</CardTitle>
              <CardDescription>
                GET /api/mobile/config — version gates and server-side feature flags.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {config.loading && !config.data ? (
                <div className="flex flex-wrap gap-2">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <Skeleton key={i} className="h-6 w-20 rounded-full" />
                  ))}
                </div>
              ) : config.error && !config.data ? (
                <ErrorState message={config.error} onRetry={config.refetch} compact />
              ) : config.data ? (
                <>
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge className="border-white/10 bg-white/[0.05] font-mono text-[11px] text-zinc-300">
                      min v{config.data.versions.min}
                    </Badge>
                    <Badge className="border-rose-500/30 bg-rose-500/10 font-mono text-[11px] text-rose-300">
                      latest v{config.data.versions.latest}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {Object.entries(config.data.features).map(([flag, on]) => (
                      <span
                        key={flag}
                        className={cn(
                          'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold',
                          on
                            ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300'
                            : 'border-zinc-500/30 bg-zinc-500/10 text-zinc-400',
                        )}
                      >
                        <span
                          className={cn('h-1.5 w-1.5 rounded-full', on ? 'bg-emerald-400' : 'bg-zinc-500')}
                          aria-hidden
                        />
                        {flag}
                      </span>
                    ))}
                  </div>
                </>
              ) : null}
            </CardContent>
          </Card>

          {/* Note */}
          <Card className="border-rose-500/20 bg-gradient-to-br from-rose-500/[0.08] to-white/[0.02]">
            <CardContent className="flex items-start gap-3 p-4">
              <Smartphone className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" aria-hidden />
              <p className="text-sm text-zinc-300">
                Same gateway, same auth — point the native app at{' '}
                <code className="rounded bg-black/50 px-1.5 py-0.5 font-mono text-xs text-rose-300">
                  /api/mobile/*
                </code>{' '}
                with{' '}
                <code className="rounded bg-black/50 px-1.5 py-0.5 font-mono text-xs text-rose-300">
                  XTransformPort=4000
                </code>
                .
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Empty-home fallback */}
      {home.data && home.data.rows.length === 0 && (
        <EmptyState title="No mobile rows" message="The mobile home feed has no content yet." />
      )}
    </Container>
  );
}

export default MobileView;
