'use client';

/**
 * player-view.tsx — Stream player for library titles. Renders mp4 <video>,
 * HLS (m3u8) via dynamic hls.js import, YouTube embeds and sandboxed iframes,
 * with a source switcher, playback-policy line and an inline stream miner
 * for titles without sources.
 */

import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Film, Loader2, MonitorPlay, Pickaxe } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/animaxia/api';
import { platform } from '@/lib/animaxia/platform';
import { useApi } from '@/lib/animaxia/hooks';
import { navigate, type AppRoute } from '@/lib/animaxia/router';
import type { PlayerResponse, PlayerSource } from '@/lib/animaxia/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { Container } from '../section';
import { EmptyState, ErrorState, TypeBadge } from '../states';

function isNotFound(message?: string | null): boolean {
  return Boolean(message && message.toLowerCase().includes('not found'));
}

function PlayerModeBadge({ mode }: { mode: PlayerResponse['mode'] }) {
  if (mode === 'direct') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-[11px] font-semibold text-emerald-300">
        <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" aria-hidden />
        Direct stream
      </span>
    );
  }
  if (mode === 'trailer') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-500/30 bg-amber-500/10 px-3 py-1 text-[11px] font-semibold text-amber-300">
        <span className="h-1.5 w-1.5 rounded-full bg-amber-400" aria-hidden />
        YouTube trailer
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] font-semibold text-zinc-400">
      <span className="h-1.5 w-1.5 rounded-full bg-zinc-500" aria-hidden />
      No source
    </span>
  );
}

export function PlayerView({ route }: { route: AppRoute }) {
  const id = Number(route.params[0]);
  const validId = Number.isInteger(id) && id > 0;
  const player = useApi(`player-${id}`, () => api.player(id), { enabled: validId });

  const [activeSource, setActiveSource] = useState<PlayerSource | null>(null);
  const [mineUrl, setMineUrl] = useState('');
  const [mining, setMining] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (player.data) setActiveSource(player.data.primary);
  }, [player.data]);

  /* ------------------------- analytics tracking ------------------------- */

  const trackedViewRef = useRef<number | null>(null);
  const trackedPlayRef = useRef<number | null>(null);

  /* Fire-and-forget 'view' event, once per content id per mount. */
  useEffect(() => {
    if (!player.data || player.data.content.id !== id) return;
    if (trackedViewRef.current === id) return;
    trackedViewRef.current = id;
    platform.recordView(id, 'view').catch(() => {});
  }, [player.data, id]);

  /* 'play' event for embed renderers (youtube/iframe), once per content id. */
  useEffect(() => {
    if (!player.data || player.data.content.id !== id) return;
    const src = activeSource ?? player.data.primary;
    if (!src || (src.type !== 'youtube' && src.type !== 'iframe')) return;
    if (trackedPlayRef.current === id) return;
    trackedPlayRef.current = id;
    platform.recordView(id, 'play').catch(() => {});
  }, [player.data, activeSource, id]);

  const trackPlay = () => {
    if (trackedPlayRef.current === id) return;
    trackedPlayRef.current = id;
    platform.recordView(id, 'play').catch(() => {});
  };

  const trackComplete = () => {
    platform.recordView(id, 'complete').catch(() => {});
  };

  useEffect(() => {
    const url = activeSource?.url;
    const el = videoRef.current;
    if (activeSource?.type !== 'm3u8' || !url || !el) return;
    let hls: { destroy: () => void } | null = null;
    let cancelled = false;
    (async () => {
      try {
        const mod = await import('hls.js');
        const Hls = mod.default;
        if (cancelled) return;
        if (Hls.isSupported()) {
          const instance = new Hls({ enableWorker: true });
          instance.loadSource(url);
          instance.attachMedia(el);
          hls = instance;
        } else if (el.canPlayType('application/vnd.apple.mpegurl')) {
          el.src = url;
        }
      } catch {
        /* hls failed to init */
      }
    })();
    return () => {
      cancelled = true;
      hls?.destroy();
    };
  }, [activeSource?.type, activeSource?.url]);

  async function handleMine(e: React.FormEvent) {
    e.preventDefault();
    if (!mineUrl.trim() || !player.data || mining) return;
    setMining(true);
    try {
      await api.miner({
        url: mineUrl.trim(),
        externalId: player.data.content.externalid,
        type: player.data.content.type,
      });
      toast.success('Stream attached');
      setMineUrl('');
      await player.refetch();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Mining failed');
    } finally {
      setMining(false);
    }
  }

  if (!validId) {
    return (
      <Container className="py-20">
        <EmptyState
          title="Title not found"
          message="The player URL is missing a valid title id."
          action={
            <Button className="bg-rose-600 font-bold hover:bg-rose-500" onClick={() => navigate('/home')}>
              Back to home
            </Button>
          }
        />
      </Container>
    );
  }

  /* useApi keeps the previous record while the key changes — only trust data matching the requested id. */
  const current = player.data && player.data.content.id === id ? player.data : null;

  if (player.loading && !current) {
    return (
      <Container className="py-8 sm:py-12">
        <div className="mx-auto w-full max-w-5xl space-y-5">
          <div className="flex items-center justify-between">
            <Skeleton className="h-9 w-36" />
            <Skeleton className="h-7 w-28 rounded-full" />
          </div>
          <Skeleton className="aspect-video w-full rounded-2xl" />
          <Skeleton className="h-24 w-full rounded-xl" />
        </div>
      </Container>
    );
  }

  if (player.error && !current) {
    if (isNotFound(player.error)) {
      return (
        <Container className="py-20">
          <EmptyState
            title="Title not found"
            message={player.error}
            action={
              <Button className="bg-rose-600 font-bold hover:bg-rose-500" onClick={() => navigate('/home')}>
                Back to home
              </Button>
            }
          />
        </Container>
      );
    }
    return (
      <Container className="py-20">
        <ErrorState message={player.error} onRetry={player.refetch} />
      </Container>
    );
  }

  const data = current;
  if (!data) return null;

  const content = data.content;
  const md = content.metadata || {};
  const overview =
    [md.overview, md.synopsis, md.description].find((v) => typeof v === 'string' && v.trim() !== '') ||
    'No synopsis available for this title.';
  const thumb = content.thumbnail || (typeof md.backdrop === 'string' ? md.backdrop : null);
  const noSource = data.mode === 'none' || !data.primary;

  /* Guard against a stale activeSource from a previous title (useApi keeps old data during key changes). */
  const effectiveSource =
    activeSource && data.sources.some((s) => s.url === activeSource.url && s.type === activeSource.type)
      ? activeSource
      : data.primary;

  return (
    <Container className="py-6 sm:py-8">
      <div className="mx-auto w-full max-w-5xl space-y-5">
        {/* Top bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Button
            variant="outline"
            className="border-white/15 bg-white/5 font-semibold hover:bg-white/10"
            onClick={() => navigate(`/content/${id}`)}
          >
            <ArrowLeft aria-hidden /> Back to details
          </Button>
          <PlayerModeBadge mode={data.mode} />
        </div>

        {/* Player surface */}
        {noSource ? (
          <div className="space-y-4">
            <EmptyState
              title="No stream sources available"
              message={
                data.note ||
                'This title has no playable sources yet. Mine a stream below and it will be attached instantly.'
              }
              icon={<MonitorPlay className="h-6 w-6" aria-hidden />}
            />
            <Card className="border-white/10 bg-white/[0.03]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Pickaxe className="h-4 w-4 text-rose-400" aria-hidden />
                  Mine a stream
                </CardTitle>
                <CardDescription>
                  Point the miner at a page or direct media URL — it extracts mp4, m3u8, iframe and YouTube sources
                  and attaches them to this title.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form className="flex flex-col gap-3 sm:flex-row" onSubmit={handleMine}>
                  <div className="flex-1">
                    <label htmlFor="player-mine-url" className="sr-only">
                      Stream or page URL
                    </label>
                    <Input
                      id="player-mine-url"
                      value={mineUrl}
                      onChange={(e) => setMineUrl(e.target.value)}
                      placeholder="https://example.com/page-or-stream"
                      className="border-white/10 bg-black/40"
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={mining || !mineUrl.trim()}
                    className="bg-rose-600 font-bold hover:bg-rose-500"
                  >
                    {mining ? <Loader2 className="animate-spin" aria-hidden /> : <Pickaxe aria-hidden />}
                    Mine &amp; attach
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="aspect-video w-full overflow-hidden rounded-2xl border border-white/10 bg-black">
            {effectiveSource?.type === 'mp4' && (
              <video
                key={effectiveSource.url}
                controls
                autoPlay
                playsInline
                className="h-full w-full"
                src={effectiveSource.url}
                onPlay={trackPlay}
                onEnded={trackComplete}
              />
            )}
            {effectiveSource?.type === 'm3u8' && (
              <video
                ref={videoRef}
                controls
                autoPlay
                playsInline
                className="h-full w-full"
                onPlay={trackPlay}
                onEnded={trackComplete}
              />
            )}
            {effectiveSource?.type === 'youtube' && (
              <iframe
                key={effectiveSource.url}
                src={`${effectiveSource.url}${effectiveSource.url.includes('?') ? '&' : '?'}autoplay=1&rel=0`}
                title={content.title}
                className="h-full w-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            )}
            {effectiveSource?.type === 'iframe' && (
              <iframe
                key={effectiveSource.url}
                src={effectiveSource.url}
                title="Embedded player"
                className="h-full w-full"
                sandbox="allow-scripts; allow-same-origin; allow-presentation; allow-popups; allow-forms"
                allowFullScreen
                referrerPolicy="no-referrer"
              />
            )}
          </div>
        )}

        {/* Source switcher */}
        {data.sources.length > 1 && (
          <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Stream sources">
            {data.sources.map((s, i) => {
              const isActive = effectiveSource?.url === s.url && effectiveSource?.type === s.type;
              return (
                <button
                  key={`${s.type}-${i}-${s.url}`}
                  type="button"
                  onClick={() => setActiveSource(s)}
                  aria-pressed={isActive}
                  className={cn(
                    'rounded-full border px-3 py-1.5 text-xs font-semibold transition',
                    isActive
                      ? 'border-rose-500/60 bg-rose-600 text-white shadow-lg shadow-rose-900/30'
                      : 'border-white/10 bg-white/[0.04] text-zinc-300 hover:border-white/25 hover:bg-white/10',
                  )}
                >
                  {s.label || `${s.type} ${i + 1}`}
                </button>
              );
            })}
          </div>
        )}

        {/* Policy line */}
        <p className="flex flex-wrap items-center gap-2 text-[11px] text-zinc-500">
          <span>Allowed by policy:</span>
          {data.allowedTypes.map((t) => (
            <span
              key={t}
              className="rounded-full border border-white/10 bg-white/[0.04] px-2 py-0.5 font-mono text-[10px] text-zinc-400"
            >
              {t}
            </span>
          ))}
        </p>

        {/* Info card */}
        <Card className="border-white/10 bg-white/[0.03] p-4 sm:p-5">
          <div className="flex flex-wrap items-start gap-4">
            {thumb ? (
              <img
                src={thumb}
                alt={`${content.title} thumbnail`}
                className="h-20 w-14 shrink-0 rounded object-cover"
              />
            ) : (
              <div className="grid h-20 w-14 shrink-0 place-items-center rounded bg-gradient-to-br from-white/10 to-white/[0.03]">
                <Film className="h-5 w-5 text-zinc-500" aria-hidden />
              </div>
            )}
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-bold text-white">{content.title}</h2>
                <TypeBadge type={content.type} />
              </div>
              <p className="mt-1.5 line-clamp-3 text-sm text-zinc-400">{overview}</p>
            </div>
            <Button
              variant="outline"
              className="shrink-0 border-white/15 bg-white/5 font-semibold hover:bg-white/10"
              onClick={() => navigate(`/content/${id}`)}
            >
              View details
            </Button>
          </div>
        </Card>
      </div>
    </Container>
  );
}
