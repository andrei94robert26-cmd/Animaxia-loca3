'use client';

/**
 * recommendations-view.tsx — "For You" page: a dice-roll random anime picker
 * plus curated rows from Jikan, TMDB and the local library.
 */

import { useState } from 'react';
import { Clapperboard, Dices, Info, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { animeToItem, api, dbToItem, mediaToItem } from '@/lib/animaxia/api';
import { useApi } from '@/lib/animaxia/hooks';
import { extItemCache, navigate } from '@/lib/animaxia/router';
import type { AnimeItem } from '@/lib/animaxia/types';
import { Button } from '@/components/ui/button';
import { Container, PageHeader } from '../section';
import { ContentRow } from '../content-row';
import { EmptyState, RatingBadge, TypeBadge } from '../states';

function Chip({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-0.5 text-[11px] font-medium text-zinc-300">
      {children}
    </span>
  );
}

export function RecommendationsView() {
  const [roll, setRoll] = useState<AnimeItem | null>(null);
  const [rolling, setRolling] = useState(false);

  const topAnime = useApi('rec-anime-top', () => api.animeTop());
  const topMovies = useApi('rec-movies-top', () => api.moviesTop());
  const popularTv = useApi('rec-tv-popular', () => api.tvPopular());
  const fresh = useApi('rec-fresh', () => api.all({ limit: 14, sort: 'createdat' }));

  async function rollDice() {
    if (rolling) return;
    setRolling(true);
    try {
      const res = await api.animeRandom();
      setRoll(res.data);
    } catch {
      toast.error('Jikan is rate-limited — try again shortly');
    } finally {
      setRolling(false);
    }
  }

  function openRollDetails(item: AnimeItem) {
    extItemCache.put(`ext:anime:${item.id}`, animeToItem(item));
    navigate(`/content/ext:anime:${item.id}`);
  }

  return (
    <Container className="space-y-10 py-8 sm:py-10">
      <PageHeader title="For You" subtitle="Hand-picked recommendations and a roll of the dice." />

      {/* Surprise me */}
      <div className="rounded-2xl bg-gradient-to-br from-rose-500/50 via-fuchsia-500/30 to-amber-500/40 p-[1px]">
        <div className="rounded-2xl bg-[#0d0d14] p-5 sm:p-7">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-xl font-black tracking-tight text-white sm:text-2xl">Surprise me</h2>
              <p className="mt-1 max-w-xl text-sm text-zinc-400">
                Pull a random anime from the Jikan vault — one click, one pick. Land a gem and keep it in your
                library.
              </p>
            </div>
            <Button
              size="lg"
              onClick={rollDice}
              disabled={rolling}
              className="bg-rose-600 font-bold text-white hover:bg-rose-500"
            >
              {rolling ? <Loader2 className="animate-spin" aria-hidden /> : <Dices aria-hidden />}
              {rolling ? 'Rolling…' : 'Roll the dice'}
            </Button>
          </div>

          <div className="mt-6">
            {roll ? (
              <div className="flex flex-col gap-6 sm:flex-row">
                <div className="w-full shrink-0 sm:w-56">
                  {roll.image ? (
                    <img
                      src={roll.image}
                      alt={`${roll.title} poster`}
                      className="aspect-[2/3] w-full rounded-xl border border-white/10 object-cover shadow-2xl shadow-black/60"
                    />
                  ) : (
                    <div className="grid aspect-[2/3] w-full place-items-center rounded-xl border border-white/10 bg-gradient-to-br from-white/[0.08] to-white/[0.02]">
                      <Clapperboard className="h-10 w-10 text-rose-400/60" aria-hidden />
                    </div>
                  )}
                </div>
                <div className="min-w-0 flex-1 space-y-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <TypeBadge type="anime" />
                    {roll.score != null && <RatingBadge value={roll.score} />}
                  </div>
                  <h3 className="text-xl font-black tracking-tight text-white sm:text-2xl">{roll.title}</h3>
                  <p className="text-xs font-semibold uppercase tracking-wider text-zinc-500">
                    {[roll.year, roll.type, roll.episodes ? `${roll.episodes} episodes` : null]
                      .filter(Boolean)
                      .join(' · ')}
                  </p>
                  {roll.genres && roll.genres.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {roll.genres.slice(0, 5).map((g) => (
                        <Chip key={g}>{g}</Chip>
                      ))}
                    </div>
                  )}
                  <p className="line-clamp-4 text-sm leading-relaxed text-zinc-400">
                    {roll.synopsis || 'No synopsis available for this pick.'}
                  </p>
                  <div className="flex flex-wrap gap-3 pt-1">
                    <Button
                      variant="outline"
                      className="border-white/15 bg-white/5 font-semibold hover:bg-white/10"
                      onClick={() => openRollDetails(roll)}
                    >
                      <Info aria-hidden /> Details
                    </Button>
                    <Button
                      variant="outline"
                      className="border-rose-500/40 bg-rose-500/10 font-semibold text-rose-300 hover:bg-rose-500/20 hover:text-rose-200"
                      onClick={rollDice}
                      disabled={rolling}
                    >
                      {rolling ? <Loader2 className="animate-spin" aria-hidden /> : <Dices aria-hidden />}
                      Roll again
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <EmptyState
                title={rolling ? 'Rolling the dice…' : 'Fate is waiting'}
                message={
                  rolling
                    ? 'Asking Jikan for a random pick.'
                    : 'Hit the dice and let fate pick your next watch from thousands of anime.'
                }
                icon={<Dices className="h-6 w-6" aria-hidden />}
              />
            )}
          </div>
        </div>
      </div>

      {/* Rows */}
      <div className="space-y-10">
        <ContentRow
          title="Top anime of all time"
          subtitle="The highest-rated series on MyAnimeList"
          items={(topAnime.data?.data || []).map(animeToItem)}
          loading={topAnime.loading}
          seeAllHref="/category/anime"
        />
        <ContentRow
          title="Top rated movies"
          subtitle="All-time greats from TMDB"
          items={(topMovies.data?.data || []).map(mediaToItem)}
          loading={topMovies.loading}
          seeAllHref="/category/movie"
        />
        <ContentRow
          title="Popular TV right now"
          subtitle="What everyone is watching"
          items={(popularTv.data?.data || []).map(mediaToItem)}
          loading={popularTv.loading}
          seeAllHref="/category/tv"
        />
        <ContentRow
          title="Fresh in your library"
          subtitle="Most recently added titles"
          items={(fresh.data?.data || []).map(dbToItem)}
          loading={fresh.loading}
          seeAllHref="/category/all"
          emptyMessage="Your library is empty — open any category and add titles from TMDB or Jikan."
        />
      </div>
    </Container>
  );
}
