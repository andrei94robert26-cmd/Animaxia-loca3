'use client';

/**
 * search-view.tsx — Universal search across the Animaxia library, MyAnimeList
 * and TMDB, with a large query box, 500 ms live debounce, instant autocomplete
 * suggestions and an Advanced tab backed by the Animaxia Search Engine
 * (filters, fuzzy matching and BM25 relevance scores).
 */

import { useEffect, useRef, useState } from 'react';
import { Loader2, Search, SearchX, SlidersHorizontal, Sparkles, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { api, animeToItem, dbToItem, mediaToItem } from '@/lib/animaxia/api';
import { platform, type SearchAdvancedResponse } from '@/lib/animaxia/platform';
import { useApi, type UseApiResult } from '@/lib/animaxia/hooks';
import { navigate, type AppRoute } from '@/lib/animaxia/router';
import type { NormalizedItem } from '@/lib/animaxia/types';
import { ContentCard } from '../content-card';
import { ContentGrid } from '../content-grid';
import { Container, PageHeader } from '../section';
import { EmptyState, ErrorState, LoadingCards, TypeBadge } from '../states';
import { cn } from '@/lib/utils';

type SearchTab = 'library' | 'anime' | 'media' | 'advanced';

const TAB_LABELS: Record<Exclude<SearchTab, 'advanced'>, string> = {
  library: 'Library',
  anime: 'Anime',
  media: 'Movies & TV',
};

interface Suggestion {
  id: number;
  title: string;
  type: string;
  thumbnail: string | null;
}

/* --------------------------- advanced tab types --------------------------- */

interface AdvancedFilters {
  q: string;
  type: string; // 'any' | 'anime' | 'movie' | …
  genre: string;
  year: string;
  minRating: string; // 'any' | '6' | '7' | '8' | '9'
  sort: 'score' | 'year' | 'rating' | 'title';
  fuzzy: boolean;
}

const ADV_TYPES = ['any', 'anime', 'movie', 'tv', 'news', 'sports', 'mined'] as const;
const ADV_RATINGS = [
  { value: 'any', label: 'Any rating' },
  { value: '6', label: '6+' },
  { value: '7', label: '7+' },
  { value: '8', label: '8+' },
  { value: '9', label: '9+' },
] as const;
const ADV_SORTS = [
  { value: 'score', label: 'Best match' },
  { value: 'year', label: 'Newest' },
  { value: 'rating', label: 'Top rated' },
  { value: 'title', label: 'A–Z' },
] as const;

export function SearchView({ route }: { route: AppRoute }) {
  const q = route.query.get('q')?.trim() || '';
  const [input, setInput] = useState(q);
  const [activeTab, setActiveTab] = useState<SearchTab>('library');

  /* Keep the box in sync when the URL query changes. */
  useEffect(() => {
    setInput(q);
  }, [q]);

  /* Live search: debounce 500 ms, only navigate when the query really changed. */
  useEffect(() => {
    const trimmed = input.trim();
    if (!trimmed || trimmed === q) return;
    const timer = setTimeout(() => {
      navigate(`/search?q=${encodeURIComponent(trimmed)}`);
    }, 500);
    return () => clearTimeout(timer);
  }, [input, q]);

  const searchRes = useApi(
    `search-${activeTab}-${q}`,
    async (): Promise<{ items: NormalizedItem[]; total: number }> => {
      if (activeTab === 'library') {
        const res = await api.all({ search: q, limit: 24 });
        return { items: res.data.map(dbToItem), total: res.total };
      }
      if (activeTab === 'anime') {
        const res = await api.animeSearch(q);
        return { items: res.data.map(animeToItem), total: res.data.length };
      }
      const res = await api.moviesSearch(q);
      return { items: res.data.map(mediaToItem), total: res.data.length };
    },
    { enabled: q.length > 0 && activeTab !== 'advanced' },
  );

  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = input.trim();
    if (trimmed) navigate(`/search?q=${encodeURIComponent(trimmed)}`);
  };

  /* ----------------------------- autocomplete ----------------------------- */

  const searchBoxRef = useRef<HTMLDivElement>(null);
  const [acOpen, setAcOpen] = useState(false);
  const [acItems, setAcItems] = useState<Suggestion[]>([]);
  const [acLoading, setAcLoading] = useState(false);
  const [acHighlight, setAcHighlight] = useState(-1);

  /* Debounced autocomplete fetch while the dropdown is open. */
  useEffect(() => {
    const query = input.trim();
    if (!acOpen || query.length < 1) {
      setAcItems([]);
      setAcLoading(false);
      setAcHighlight(-1);
      return;
    }
    setAcLoading(true);
    let cancelled = false;
    const timer = setTimeout(async () => {
      try {
        const res = await platform.autocomplete(query);
        if (!cancelled) setAcItems(res.suggestions);
      } catch {
        if (!cancelled) setAcItems([]);
      } finally {
        if (!cancelled) setAcLoading(false);
      }
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [input, acOpen]);

  /* Close on click-outside. */
  useEffect(() => {
    if (!acOpen) return undefined;
    const onDown = (e: MouseEvent) => {
      if (searchBoxRef.current && !searchBoxRef.current.contains(e.target as Node)) {
        setAcOpen(false);
      }
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [acOpen]);

  function pickSuggestion(s: Suggestion) {
    setInput('');
    setAcOpen(false);
    setAcItems([]);
    navigate(`/content/${s.id}`);
  }

  function handleAcKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (!acOpen) return;
    if (e.key === 'Escape') {
      e.preventDefault();
      setAcOpen(false);
      return;
    }
    if (!acItems.length) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setAcHighlight((h) => (h + 1) % acItems.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setAcHighlight((h) => (h <= 0 ? acItems.length - 1 : h - 1));
    } else if (e.key === 'Enter' && acHighlight >= 0 && acItems[acHighlight]) {
      e.preventDefault();
      pickSuggestion(acItems[acHighlight]);
    }
  }

  const showDropdown = acOpen && input.trim().length >= 1;

  return (
    <Container className="space-y-8 py-8 sm:py-10">
      <PageHeader
        title="Search"
        subtitle="One box, every source — your library, MyAnimeList and TMDB."
      />

      <form onSubmit={submit} role="search" aria-label="Search Animaxia" className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1" ref={searchBoxRef}>
          <Search
            className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-zinc-500"
            aria-hidden
          />
          <Input
            value={input}
            onChange={(event) => {
              setInput(event.target.value);
              setAcOpen(true);
              setAcHighlight(-1);
            }}
            onFocus={() => setAcOpen(true)}
            onKeyDown={handleAcKeyDown}
            placeholder="Search anime, movies, TV shows…"
            aria-label="Search query"
            aria-autocomplete="list"
            aria-expanded={showDropdown}
            aria-controls={showDropdown ? 'search-suggestions' : undefined}
            className="h-12 rounded-xl border-white/10 bg-white/[0.04] pl-12 pr-11 text-base text-zinc-100 placeholder:text-zinc-500 focus-visible:border-rose-500/50 focus-visible:ring-rose-500/30"
          />
          {input ? (
            <button
              type="button"
              onClick={() => setInput('')}
              aria-label="Clear search"
              className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-zinc-500 transition hover:bg-white/10 hover:text-zinc-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/60"
            >
              <X className="h-4 w-4" aria-hidden />
            </button>
          ) : null}

          {/* Autocomplete dropdown */}
          {showDropdown && (
            <div
              id="search-suggestions"
              role="listbox"
              aria-label="Search suggestions"
              className="custom-scrollbar absolute inset-x-0 top-full z-20 mt-2 max-h-80 overflow-y-auto rounded-xl border border-white/10 bg-[#12121c] shadow-2xl shadow-black/60"
            >
              {acLoading ? (
                <div className="flex items-center gap-2 px-4 py-3 text-sm text-zinc-500">
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Searching…
                </div>
              ) : acItems.length === 0 ? (
                <p className="px-4 py-3 text-sm text-zinc-500">No suggestions</p>
              ) : (
                acItems.map((s, i) => (
                  <button
                    key={s.id}
                    type="button"
                    role="option"
                    aria-selected={acHighlight === i}
                    onMouseEnter={() => setAcHighlight(i)}
                    onClick={() => pickSuggestion(s)}
                    className={cn(
                      'flex w-full items-center gap-3 px-3 py-2.5 text-left transition',
                      acHighlight === i ? 'bg-white/[0.06]' : 'hover:bg-white/[0.06]',
                    )}
                  >
                    {s.thumbnail ? (
                      <img
                        src={s.thumbnail}
                        alt=""
                        loading="lazy"
                        className="h-10 w-8 shrink-0 rounded object-cover"
                      />
                    ) : (
                      <span className="grid h-10 w-8 shrink-0 place-items-center rounded bg-gradient-to-br from-white/10 to-white/[0.03]">
                        <Search className="h-3.5 w-3.5 text-zinc-600" aria-hidden />
                      </span>
                    )}
                    <span className="min-w-0 flex-1 truncate text-sm font-medium text-zinc-200">{s.title}</span>
                    <TypeBadge type={s.type} />
                  </button>
                ))
              )}
            </div>
          )}
        </div>
        <Button
          type="submit"
          className="h-12 rounded-xl bg-rose-600 px-7 text-base font-bold text-white hover:bg-rose-500"
        >
          Search
        </Button>
      </form>

      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as SearchTab)}>
        <TabsList className="h-10 w-full justify-start gap-1 rounded-xl border border-white/10 bg-white/[0.03] p-1 sm:w-auto">
          <TabsTrigger
            value="library"
            className="px-4 text-zinc-400 hover:text-zinc-100 data-[state=active]:bg-rose-600 data-[state=active]:text-white data-[state=active]:shadow-rose-900/40 sm:px-5"
          >
            Library
          </TabsTrigger>
          <TabsTrigger
            value="anime"
            className="px-4 text-zinc-400 hover:text-zinc-100 data-[state=active]:bg-rose-600 data-[state=active]:text-white data-[state=active]:shadow-rose-900/40 sm:px-5"
          >
            Anime
          </TabsTrigger>
          <TabsTrigger
            value="media"
            className="px-4 text-zinc-400 hover:text-zinc-100 data-[state=active]:bg-rose-600 data-[state=active]:text-white data-[state=active]:shadow-rose-900/40 sm:px-5"
          >
            Movies &amp; TV
          </TabsTrigger>
          <TabsTrigger
            value="advanced"
            className="px-4 text-zinc-400 hover:text-zinc-100 data-[state=active]:bg-rose-600 data-[state=active]:text-white data-[state=active]:shadow-rose-900/40 sm:px-5"
          >
            <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden /> Advanced
          </TabsTrigger>
        </TabsList>

        {(['library', 'anime', 'media'] as const).map((tab) => (
          <TabsContent key={tab} value={tab} className="pt-6">
            {q ? (
              <ResultsBlock label={TAB_LABELS[tab]} q={q} res={searchRes} />
            ) : (
              <EmptyState
                icon={<SearchX className="h-6 w-6" aria-hidden />}
                title="Search Animaxia"
                message="Find anime, movies and TV shows across your library and live providers."
              />
            )}
          </TabsContent>
        ))}

        <TabsContent value="advanced" className="pt-6">
          <AdvancedPanel />
        </TabsContent>
      </Tabs>
    </Container>
  );
}

/* ----------------------------- local helper ------------------------------ */

function ResultsBlock({
  label,
  q,
  res,
}: {
  label: string;
  q: string;
  res: UseApiResult<{ items: NormalizedItem[]; total: number }>;
}) {
  if (res.error && !res.loading) {
    return <ErrorState message={res.error} onRetry={res.refetch} />;
  }
  const items = res.data?.items ?? [];
  const total = res.data?.total ?? 0;
  return (
    <div className="space-y-4">
      {!res.loading && res.data ? (
        <p className="text-sm text-zinc-500">
          <span className="font-semibold text-zinc-200">
            {total > items.length ? `${items.length} of ${total}` : items.length}
          </span>{' '}
          {items.length === 1 && total <= 1 ? 'result' : 'results'} for{' '}
          <span className="font-semibold text-zinc-200">“{q}”</span> in {label}
        </p>
      ) : null}
      <ContentGrid
        items={items}
        loading={res.loading}
        skeletonCount={12}
        emptyTitle={`No results for “${q}”`}
        emptyMessage="Try a different keyword or switch to another tab."
      />
    </div>
  );
}

/* ------------------------------ advanced tab ----------------------------- */

function AdvancedPanel() {
  const [q, setQ] = useState('');
  const [type, setType] = useState('any');
  const [genre, setGenre] = useState('');
  const [year, setYear] = useState('');
  const [minRating, setMinRating] = useState('any');
  const [sort, setSort] = useState<AdvancedFilters['sort']>('score');
  const [fuzzy, setFuzzy] = useState(true);
  const [submitted, setSubmitted] = useState<AdvancedFilters | null>(null);

  const engine = useApi('search-status', () => platform.searchStatus());

  const results = useApi(
    `search-advanced-${submitted ? JSON.stringify(submitted) : 'idle'}`,
    async (): Promise<SearchAdvancedResponse> => {
      if (!submitted) throw new Error('No query');
      return platform.searchAdvanced({
        q: submitted.q,
        type: submitted.type === 'any' ? undefined : submitted.type,
        genre: submitted.genre.trim() || undefined,
        year: submitted.year.trim() || undefined,
        minRating: submitted.minRating === 'any' ? undefined : Number(submitted.minRating),
        sort: submitted.sort,
        fuzzy: submitted.fuzzy,
        limit: 24,
      });
    },
    { enabled: submitted !== null },
  );

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = q.trim();
    if (!trimmed) return;
    setSubmitted({ q: trimmed, type, genre: genre.trim(), year: year.trim(), minRating, sort, fuzzy });
  }

  const rows = results.data?.data ?? [];
  const hintChips: { key: string; label: string }[] = [];
  if (submitted) {
    if (submitted.type !== 'any') hintChips.push({ key: 'type', label: submitted.type });
    if (submitted.genre) hintChips.push({ key: 'genre', label: submitted.genre });
    if (submitted.year) hintChips.push({ key: 'year', label: submitted.year });
    if (submitted.minRating !== 'any')
      hintChips.push({ key: 'rating', label: `rating ≥ ${submitted.minRating}` });
    if (!submitted.fuzzy) hintChips.push({ key: 'fuzzy', label: 'exact match' });
  }

  return (
    <div className="space-y-6">
      {/* Filter panel */}
      <form
        onSubmit={handleSubmit}
        className="space-y-5 rounded-xl border border-white/10 bg-white/[0.03] p-4 sm:p-5"
        aria-label="Advanced search filters"
      >
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <div className="space-y-2 sm:col-span-2 lg:col-span-1">
            <Label htmlFor="adv-q">Query</Label>
            <Input
              id="adv-q"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Title, genre or keyword…"
              className="border-white/10 bg-black/40"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="adv-type">Type</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger id="adv-type" className="w-full border-white/10 bg-black/40">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent className="border-white/10 bg-[#12121a]">
                {ADV_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>
                    {t === 'any' ? 'Any type' : t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="adv-genre">Genre</Label>
            <Input
              id="adv-genre"
              value={genre}
              onChange={(e) => setGenre(e.target.value)}
              placeholder="e.g. Action"
              className="border-white/10 bg-black/40"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="adv-year">Year</Label>
            <Input
              id="adv-year"
              value={year}
              onChange={(e) => setYear(e.target.value.replace(/[^0-9]/g, '').slice(0, 4))}
              inputMode="numeric"
              placeholder="e.g. 2024"
              className="border-white/10 bg-black/40"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="adv-rating">Minimum rating</Label>
            <Select value={minRating} onValueChange={setMinRating}>
              <SelectTrigger id="adv-rating" className="w-full border-white/10 bg-black/40">
                <SelectValue placeholder="Any rating" />
              </SelectTrigger>
              <SelectContent className="border-white/10 bg-[#12121a]">
                {ADV_RATINGS.map((r) => (
                  <SelectItem key={r.value} value={r.value}>
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="adv-sort">Sort by</Label>
            <Select value={sort} onValueChange={(v) => setSort(v as AdvancedFilters['sort'])}>
              <SelectTrigger id="adv-sort" className="w-full border-white/10 bg-black/40">
                <SelectValue placeholder="Best match" />
              </SelectTrigger>
              <SelectContent className="border-white/10 bg-[#12121a]">
                {ADV_SORTS.map((s) => (
                  <SelectItem key={s.value} value={s.value}>
                    {s.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-black/40 px-4 py-2.5 sm:col-span-2 lg:col-span-2">
            <div>
              <Label htmlFor="adv-fuzzy" className="text-sm font-medium text-zinc-200">
                Fuzzy matching
              </Label>
              <p className="text-xs text-zinc-500">Tolerate typos with Levenshtein term expansion.</p>
            </div>
            <Switch
              id="adv-fuzzy"
              checked={fuzzy}
              onCheckedChange={setFuzzy}
              aria-label="Fuzzy matching"
              className="data-[state=checked]:bg-rose-600"
            />
          </div>
        </div>
        <Button type="submit" disabled={!q.trim()} className="bg-rose-600 font-bold hover:bg-rose-500">
          <Search aria-hidden /> Search
        </Button>
      </form>

      {/* Results */}
      {!submitted ? (
        <EmptyState
          icon={<SlidersHorizontal className="h-6 w-6" aria-hidden />}
          title="Advanced search"
          message="Combine filters and fuzzy matching to query the Animaxia Search Engine directly."
        />
      ) : results.error && !results.loading && !results.data ? (
        <ErrorState message={results.error} onRetry={results.refetch} />
      ) : results.loading ? (
        <LoadingCards count={12} />
      ) : (
        <div className="space-y-4">
          {/* Meta line */}
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm text-zinc-500">
              <span className="font-semibold text-zinc-200">{results.data?.total ?? 0}</span>{' '}
              {(results.data?.total ?? 0) === 1 ? 'result' : 'results'} ·{' '}
              <span className="font-semibold text-zinc-200">{results.data?.took ?? 0}ms</span> · Animaxia Search
              Engine
            </p>
            {engine.data?.engine && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-fuchsia-500/30 bg-fuchsia-500/10 px-2.5 py-0.5 font-mono text-[10px] font-semibold text-fuchsia-300">
                <Sparkles className="h-3 w-3" aria-hidden />
                {engine.data.engine}
              </span>
            )}
            {hintChips.map((chip) => (
              <span
                key={chip.key}
                className="rounded-full border border-white/10 bg-white/[0.05] px-2.5 py-0.5 text-[11px] font-semibold text-zinc-400"
              >
                {chip.label}
              </span>
            ))}
          </div>

          {rows.length === 0 ? (
            <EmptyState
              title="No titles match those filters"
              message="Try loosening the type, rating or genre filters — or turn fuzzy matching on."
            />
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
              {rows.map((row) => (
                <div key={`adv-${row.id}`} className="relative">
                  <ContentCard item={dbToItem(row)} />
                  <span
                    title={`Relevance score ${row._score.toFixed(1)}`}
                    className="absolute right-2 top-9 z-10 inline-flex items-center gap-1 rounded-full border border-rose-500/40 bg-black/70 px-2 py-0.5 text-[10px] font-bold text-rose-300 backdrop-blur"
                  >
                    <Sparkles className="h-2.5 w-2.5" aria-hidden />
                    {row._score.toFixed(1)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
