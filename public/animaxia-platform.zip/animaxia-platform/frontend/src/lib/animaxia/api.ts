/**
 * api.ts — Animaxia API client. All requests go through the gateway using
 * relative URLs with the XTransformPort query param (backend runs on :4000).
 * Never hardcode hosts or ports in fetch URLs.
 */

import type {
  AllResponse,
  AnimeItem,
  Competition,
  DbContent,
  F1Race,
  F1Standing,
  FootballMatch,
  FootballTableEntry,
  HealthResponse,
  MediaItem,
  MinerExtraction,
  NewsItem,
  NormalizedItem,
  PlayerResponse,
  SeedResponse,
  TvScheduleItem,
} from './types';

export const BACKEND_PORT = 4000;

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

type ParamValue = string | number | boolean | undefined | null;

export function apiUrl(path: string, params?: Record<string, ParamValue>): string {
  const search = new URLSearchParams();
  search.set('XTransformPort', String(BACKEND_PORT));
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== null && value !== '') search.set(key, String(value));
    }
  }
  return `${path}?${search.toString()}`;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      ...init,
      headers: { 'Content-Type': 'application/json', ...(init?.headers as Record<string, string> | undefined) },
    });
  } catch {
    throw new ApiError('Cannot reach the Animaxia backend — it may be restarting', 0);
  }
  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    body = null;
  }
  if (!res.ok) {
    const message =
      (body as { error?: string } | null)?.error || `Request failed with status ${res.status}`;
    throw new ApiError(message, res.status);
  }
  return body as T;
}

export const api = {
  /* ------------------------------- core ------------------------------- */
  health: () => request<HealthResponse>(apiUrl('/api/health')),
  all: (p: { page?: number; limit?: number; type?: string; search?: string; sort?: string } = {}) =>
    request<AllResponse>(apiUrl('/api/all', p)),
  content: (id: number | string) => request<DbContent>(apiUrl(`/api/content/${id}`)),
  contentByExternalId: (externalid: string) =>
    request<DbContent>(apiUrl(`/api/content/external/${encodeURIComponent(externalid)}`)),
  player: (id: number | string) => request<PlayerResponse>(apiUrl(`/api/content/${id}/player`)),
  upsertContent: (body: {
    externalid: string;
    type?: string;
    title: string;
    thumbnail?: string | null;
    metadata?: Record<string, unknown>;
  }) =>
    request<{ ok: true; record: DbContent; created: boolean }>(apiUrl('/api/content'), {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  deleteContent: (id: number) =>
    request<{ ok: true; deleted: DbContent }>(apiUrl(`/api/content/${id}`), { method: 'DELETE' }),
  miner: (body: { url: string; type?: string; externalId?: string }) =>
    request<{ ok: true; extraction: MinerExtraction; record: DbContent }>(apiUrl('/api/miner'), {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  seed: () =>
    request<SeedResponse>(apiUrl('/api/admin/seed'), { method: 'POST', body: '{}' }),

  /* ------------------------------- anime ------------------------------- */
  animeTop: (page = 1) => request<{ data: AnimeItem[] }>(apiUrl('/api/anime/top', { page })),
  animeSearch: (q: string, limit = 20) =>
    request<{ data: AnimeItem[] }>(apiUrl('/api/anime/search', { q, limit })),
  animeSeason: () => request<{ data: AnimeItem[] }>(apiUrl('/api/anime/season')),
  animeRandom: () => request<{ data: AnimeItem }>(apiUrl('/api/anime/random')),
  animeById: (id: string | number) => request<{ data: AnimeItem }>(apiUrl(`/api/anime/${id}`)),

  /* ------------------------------ movies / tv ------------------------------ */
  moviesTrending: (window: 'day' | 'week' = 'day', page = 1) =>
    request<{ data: MediaItem[] }>(apiUrl('/api/movies/trending', { window, page })),
  moviesPopular: (page = 1) => request<{ data: MediaItem[] }>(apiUrl('/api/movies/popular', { page })),
  moviesTop: (page = 1) => request<{ data: MediaItem[] }>(apiUrl('/api/movies/top', { page })),
  moviesUpcoming: (page = 1) => request<{ data: MediaItem[] }>(apiUrl('/api/movies/upcoming', { page })),
  moviesSearch: (q: string, page = 1) =>
    request<{ data: MediaItem[] }>(apiUrl('/api/movies/search', { q, page })),
  movieById: (id: string | number) => request<{ data: MediaItem }>(apiUrl(`/api/movies/${id}`)),
  tvTrending: (window: 'day' | 'week' = 'day', page = 1) =>
    request<{ data: MediaItem[] }>(apiUrl('/api/tv/trending', { window, page })),
  tvPopular: (page = 1) => request<{ data: MediaItem[] }>(apiUrl('/api/tv/popular', { page })),
  tvTop: (page = 1) => request<{ data: MediaItem[] }>(apiUrl('/api/tv/top', { page })),
  tvSearch: (q: string, page = 1) => request<{ data: MediaItem[] }>(apiUrl('/api/tv/search', { q, page })),
  tvById: (id: string | number) => request<{ data: MediaItem }>(apiUrl(`/api/tv/${id}`)),
  tvSchedule: () => request<{ data: TvScheduleItem[] }>(apiUrl('/api/tv/schedule')),

  /* -------------------------------- news -------------------------------- */
  news: (source: string = 'all', limit = 20) =>
    request<{ data: NewsItem[] }>(apiUrl('/api/news', { source, limit })),

  /* ------------------------------- sports ------------------------------- */
  footballCompetitions: () => request<{ data: Competition[] }>(apiUrl('/api/sports/football/competitions')),
  footballStandings: (competition = 'PL') =>
    request<{ data: { competition: string; table: FootballTableEntry[] } }>(
      apiUrl('/api/sports/football/standings', { competition }),
    ),
  footballMatches: (competition = 'PL', limit = 10) =>
    request<{ data: FootballMatch[] }>(apiUrl('/api/sports/football/matches', { competition, limit })),
  f1Standings: () => request<{ data: F1Standing[] }>(apiUrl('/api/sports/f1/standings')),
  f1Schedule: () => request<{ data: F1Race[] }>(apiUrl('/api/sports/f1/schedule')),
};

/* ----------------------------- normalizers ----------------------------- */

export function dbToItem(c: DbContent): NormalizedItem {
  const md = c.metadata || {};
  const sources = md.player?.sources || md.sources;
  return {
    key: `db-${c.id}`,
    kind: 'db',
    dbId: c.id,
    title: c.title,
    image: c.thumbnail || md.backdrop || null,
    backdrop: md.backdrop || null,
    overview: md.overview || md.synopsis || md.description || undefined,
    rating: typeof md.rating === 'number' ? md.rating : typeof md.score === 'number' ? md.score : null,
    year: (md.year as string | number | undefined) ?? null,
    type: c.type || 'mined',
    genres: Array.isArray(md.genres) ? md.genres.map(String) : undefined,
    playable: Boolean(sources && sources.length > 0),
    source: typeof md.source === 'string' ? md.source : undefined,
  };
}

export function animeToItem(a: AnimeItem): NormalizedItem {
  return {
    key: `anime-${a.id}`,
    kind: 'external',
    extType: 'anime',
    extId: String(a.id),
    title: a.title,
    image: a.image || null,
    overview: a.synopsis || undefined,
    rating: a.score ?? null,
    year: a.year ?? null,
    type: 'anime',
    genres: a.genres,
    url: a.url,
    source: a.source || 'jikan',
  };
}

export function mediaToItem(m: MediaItem): NormalizedItem {
  return {
    key: `${m.mediaType}-${m.id}`,
    kind: 'external',
    extType: m.mediaType,
    extId: String(m.id),
    title: m.title,
    image: m.image || m.backdrop || null,
    backdrop: m.backdrop || null,
    overview: m.overview || undefined,
    rating: m.rating ?? null,
    year: m.year ?? null,
    type: m.mediaType,
    genres: m.genres,
    source: m.source || 'tmdb',
  };
}

export function newsToItem(n: NewsItem): NormalizedItem {
  return {
    key: `news-${n.link}`,
    kind: 'link',
    title: n.title,
    image: n.image || null,
    overview: n.description || undefined,
    type: 'news',
    url: n.link,
    source: n.source,
  };
}

export function scheduleToItem(s: TvScheduleItem): NormalizedItem {
  return {
    key: `tvschedule-${s.id}`,
    kind: 'link',
    title: `${s.show} — ${s.title}`,
    image: s.image || null,
    overview: s.summary || undefined,
    type: 'tv',
    url: s.url,
    source: s.network || 'TVmaze',
  };
}
