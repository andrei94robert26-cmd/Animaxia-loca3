/**
 * types.ts — Animaxia shared TypeScript types mirroring the backend API contract.
 */

export type PlayerSourceType = 'mp4' | 'm3u8' | 'iframe' | 'youtube';

export interface PlayerSource {
  type: PlayerSourceType;
  url: string;
  label?: string;
}

export interface ContentMetadata {
  overview?: string;
  synopsis?: string;
  description?: string;
  rating?: number;
  score?: number;
  year?: string | number;
  genres?: string[];
  backdrop?: string;
  source?: string;
  mediaType?: string;
  url?: string;
  status?: string;
  episodes?: number;
  studios?: string[];
  trailerKey?: string;
  tagline?: string;
  runtime?: number;
  cast?: { name: string; character?: string; profile?: string }[];
  mined?: { at?: string; url?: string; siteName?: string; mp4?: string[]; m3u8?: string[]; iframe?: string[]; youtube?: string[] };
  player?: { sources?: PlayerSource[] };
  sources?: PlayerSource[];
  [key: string]: unknown;
}

export interface DbContent {
  id: number;
  externalid: string;
  type: string;
  title: string;
  metadata: ContentMetadata;
  thumbnail: string | null;
  createdat: string;
}

export interface AllResponse {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  data: DbContent[];
  warning?: string;
}

export interface PlayerResponse {
  content: DbContent;
  mode: 'direct' | 'trailer' | 'none';
  allowedTypes: string[];
  sources: PlayerSource[];
  primary: PlayerSource | null;
  note?: string;
}

export interface AnimeItem {
  id: number;
  title: string;
  image?: string;
  score?: number;
  year?: number | string;
  type?: string;
  genres?: string[];
  synopsis?: string;
  url?: string;
  status?: string;
  episodes?: number;
  studios?: string[];
  source?: string;
}

export interface MediaItem {
  id: number;
  title: string;
  image?: string;
  backdrop?: string;
  overview?: string;
  rating?: number;
  year?: string;
  mediaType: 'movie' | 'tv';
  genres?: string[];
  trailerKey?: string;
  tagline?: string;
  runtime?: number;
  cast?: { name: string; character?: string; profile?: string }[];
  source?: string;
}

export interface NewsItem {
  title: string;
  link: string;
  pubDate?: string;
  description?: string;
  image?: string;
  source: string;
}

export interface TvScheduleItem {
  id: number;
  title: string;
  show: string;
  airtime?: string;
  season?: number;
  number?: number;
  network?: string;
  image?: string;
  summary?: string;
  url?: string;
}

export interface FootballTableEntry {
  rank: number;
  team: string;
  teamCrest?: string;
  played: number;
  won: number;
  draw: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDifference: number;
  points: number;
}

export interface FootballMatch {
  id: number;
  utcDate: string;
  status: string;
  matchday?: number;
  home: string;
  away: string;
  homeCrest?: string;
  awayCrest?: string;
  score: { home: number | null; away: number | null };
}

export interface Competition {
  id: number;
  code: string;
  name: string;
  area?: string;
}

export interface F1Standing {
  position: number;
  driver: string;
  team: string;
  points: number;
  wins: number;
}

export interface F1Race {
  round: number;
  race: string;
  date: string;
  time?: string;
  circuit?: string;
  locality?: string;
  country?: string;
}

export interface MinerExtraction {
  url: string;
  finalUrl?: string;
  title?: string;
  description?: string;
  thumbnail?: string;
  siteName?: string;
  mp4: string[];
  m3u8: string[];
  iframe: string[];
  youtube: string[];
  bytesRead?: number;
  elapsedMs?: number;
  /** Legacy aliases kept for compatibility. */
  bytes?: number;
  ms?: number;
  contentType?: string;
}

export interface HealthResponse {
  status: string;
  service: string;
  version: string;
  env: string;
  uptimeSec: number;
  timestamp: string;
  db: {
    driver: 'postgres' | 'local-fallback';
    connected: boolean;
    totalItems: number;
    countsByType: Record<string, number>;
    lastError?: string;
  };
  cache: { keys: number; hits: number; misses: number; hitRate: number; enabled: boolean; ttlMs: number };
  rateLimit: { windowMs: number; max: number; trackedClients: number; totalLimited: number };
  providers: { name: string; state: string; failures: number; lastError?: string }[];
  player: { allowedTypes: string[] };
}

export interface SeedResponse {
  ok: true;
  added: { movie: number; tv: number; anime: number; demo: number };
  totalItems: number;
  animeSource: string;
}

/**
 * Normalized display item used by every card/row/hero component.
 * kind:
 *  - 'db'       → row in the Animaxia library (dbId present)
 *  - 'external' → live provider item (extType + extId present, detail page fetches live)
 *  - 'link'     → opens an external URL (news articles, TVmaze entries)
 */
export interface NormalizedItem {
  key: string;
  kind: 'db' | 'external' | 'link';
  dbId?: number;
  extType?: 'movie' | 'tv' | 'anime';
  extId?: string;
  title: string;
  image?: string | null;
  backdrop?: string | null;
  overview?: string;
  rating?: number | null;
  year?: string | number | null;
  type: string;
  genres?: string[];
  url?: string;
  source?: string;
  playable?: boolean;
}
